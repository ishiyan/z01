﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the MatHold pattern.
        /// </summary>
        public const int MatHoldCandlesticks = 5;

        /// <summary>
        /// Specifies the the maximum percentage of the first white body the reaction days can penetrate
        /// (it is to specify how much the reaction days should be "higher than the reaction days of the
        /// rising three methods").
        /// The value must be in range [0, 3e+37], the default value is 0.5.
        /// </summary>
        public double MatHoldPenetrationFactor = 0.5;

        /// <summary>
        /// The MatHold pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int MatHold(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - MatHoldCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count], ohlcv5 = ohlcvList[++count];

            // Must have:
            // - first candle: long white candle,
            // - upside gap between the first and the second bodies,
            // - second candle: small black candle,
            // - third and fourth candles: falling small real body candlesticks (commonly black) that hold within the long
            // white candle's body and are higher than the reaction days of the rising three methods,
            // - fifth candle: white candle that opens above the previous small candle's close and closes higher than the
            // high of the highest reaction day.
            // "Hold within" means "a part of the real body must be within".
            // Output is positive (1 to 100): mat hold is always bullish.

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsWhite(ohlcv5) && // 5th: white
                IsRealBodyGapUp(ohlcv1, ohlcv2) && // upside gap 1st to 2nd
                Math.Min(ohlcv3.Open, ohlcv3.Close) < ohlcv1.Close && // 3rd hold within 1st: a part of the real body must be within 1st real body
                Math.Min(ohlcv4.Open, ohlcv4.Close) < ohlcv1.Close) // 4th hold within 1st: a part of the real body must be within 1st real body
            {
                double max3 = Math.Max(ohlcv3.Open, ohlcv3.Close);
                if (max3 < ohlcv2.Open && // 3rd is falling
                    Math.Max(ohlcv4.Open, ohlcv4.Close) < max3 && // 4th is falling
                    ohlcv5.Open > ohlcv4.Close && // 5th opens above the prior close
                    ohlcv5.Close > Math.Max(Math.Max(ohlcv3.High, ohlcv2.High), ohlcv4.High)) // 5th closes above the highest high of the reaction days
                {
                    double penetration1 = ohlcv1.Close - RealBody(ohlcv1) * MatHoldPenetrationFactor;
                    if (Math.Min(ohlcv3.Open, ohlcv3.Close) > penetration1 && // reaction days penetrate first body less than penetration percent
                        Math.Min(ohlcv4.Open, ohlcv4.Close) > penetration1 && // reaction days penetrate first body less than penetration percent
                        RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1) && // 1st: long
                        RealBody(ohlcv2) > shortRealBodyCriterion.AverageValue(ohlcvList, 4, ohlcv2) && // 2nd: short
                        RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv3) && // 3rd: short
                        RealBody(ohlcv4) > shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv4)) // 4th: short
                        return 100;
                }
            }

            return 0;
        }
    }
}
