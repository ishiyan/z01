﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Hikkake pattern.
        /// </summary>
        public const int HikkakeCandlesticks = 3;

        /// <summary>
        /// The Hikkake pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Hikkake(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HikkakeCandlesticks;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];
            return HikkakeInternal(ohlcv1, ohlcv2, ohlcv3, null);
        }

        /// <summary>
        /// The Hikkake pattern confirmation.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HikkakeConfirmation(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HikkakeCandlesticks - 1;

            // One day ago.
            int index = count;
            Ohlcv ohlcv1 = ohlcvList[index], ohlcv2 = ohlcvList[++index], ohlcv3 = ohlcvList[++index], confirmation = ohlcvList[++index]; 
            int result = HikkakeInternal(ohlcv1, ohlcv2, ohlcv3, confirmation);
            if (result != 0)
                return result;

            if (count > 0)
            {
                // Two days ago.
                ohlcv3 = ohlcvList[count - 1];
                result = HikkakeInternal(ohlcv3, ohlcv1, ohlcv2, confirmation);
                if (result != 0)
                    return result;

                if (count > 1)
                {
                    // Three days ago.
                    ohlcv2 = ohlcvList[count - 2];
                    result = HikkakeInternal(ohlcv2, ohlcv3, ohlcv1, confirmation);
                    if (result != 0)
                        return result;
                }
            }

            return 0;
        }

        private static int HikkakeInternal(Ohlcv ohlcv1, Ohlcv ohlcv2, Ohlcv ohlcv3, Ohlcv confirmation)
        {
            // Must have:
            // - first and second candles: inside bar (2nd has lower high and higher low than 1st),
            // - third candle: lower high and lower low than 2nd (higher high and higher low than 2nd).
            // Output is is positive (1 to 100) or negative (-1 to -100) meaning bullish or bearish hikkake.
            // Confirmation could come in the next 3 days with a day that closes higher than the high (lower than the low) of the 2nd candle.
            // The confirmation output is equal to 100 + the bullish hikkake result or -100 - the bearish hikkake result.
            // If confirmation and a new hikkake come at the same bar, only the new hikkake is reported (the new hikkake overwrites the confirmation of the old hikkake).

            if (ohlcv2.High < ohlcv1.High && ohlcv2.Low > ohlcv1.Low) // 2nd: has lower high and higher low than 1st
            {
                if (ohlcv3.High < ohlcv2.High && ohlcv3.Low < ohlcv2.Low) // 3rd: (bull) lower high and lower low
                {
                    if (null != confirmation)
                    {
                        if (confirmation.Close > ohlcv2.High) // confirmation close higher than the high of 2nd
                            return 100;
                        return 0;
                    }
                    return 50;
                }

                if (ohlcv3.High > ohlcv2.High && ohlcv3.Low > ohlcv2.Low) // 3rd: (bear) higher high and higher low
                {
                    if (null != confirmation)
                    {
                        if (confirmation.Close < ohlcv2.High) // confirmation close lower than the low of 2nd
                            return -100;
                        return 0;
                    }
                    return -50;
                }
            }

            return 0;
        }
    }
}
