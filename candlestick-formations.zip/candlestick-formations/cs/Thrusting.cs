﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Thrusting pattern.
        /// </summary>
        public const int ThrustingCandlesticks = 2;

        /// <summary>
        /// The Thrusting pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Thrusting(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThrustingCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: white candle with open below previous day low and close into previous day body under the midpoint,
            // to differentiate it from in-neck the close should not be equal to the black candle's close.
            // The meaning of "moves well within" is specified with MorningDojiStarPenetrationFactor
            // and "moves" should mean the real body should not be short - Greg Morris wants it to be long,
            // someone else want it to be relatively long.
            // Output is negative (-1 to -100): thrusting pattern is always bearish.
            // The user should consider that thrusting pattern is significant when it appears in a downtrend
            // and it could be even bullish "when coming in an uptrend or occurring twice within several days" (Steve Nison says),
            // while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                ohlcv2.Open < ohlcv1.Low) // 2nd: open below prior low 
            {
                double realBody1 = RealBody(ohlcv1);
                if (ohlcv2.Close <= ohlcv1.Close + realBody1 * 0.5 && // 2nd: close under the midpoint
                    ohlcv2.Close > ohlcv1.Close + equalCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 2nd: close into prior body
                    realBody1 > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1)) // 1st: long real body
                return -100;
            }

            return 0;
        }
    }
}
