﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ThreeStarsInTheSouth pattern.
        /// </summary>
        public const int ThreeStarsInTheSouthCandlesticks = 3;

        /// <summary>
        /// The ThreeStarsInTheSouth pattern.
        /// </summary>
        public int ThreeStarsInTheSouth(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeStarsInTheSouthCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle with long lower shadow,
            // - second candle: smaller black candle that opens higher than prior close but within prior candle's range
            //   and trades lower than prior close but not lower than prior low and closes off of its low (it has a shadow),
            // - third candle: small black marubozu (or candle with very short shadows) engulfed by prior candle's range.
            // Output is positive (1 to 100): 3 stars in the south is always bullish.
            // The user should consider that 3 stars in the south is significant when it appears in a downtrend, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv2.Open > ohlcv1.Close && ohlcv2.Open <= ohlcv1.High && // 2nd: opens higher than prior close but within prior candle's range
                ohlcv2.Low < ohlcv1.Close && ohlcv2.Low >= ohlcv1.Low && // 2nd: trades lower than prior close but not lower than prior low and closes off of its low
                ohlcv3.Low > ohlcv2.Low && ohlcv3.High < ohlcv2.High && // 3rd: engulfed by prior candle's range
                LowerShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: has a lower shadow
                RealBody(ohlcv1) < longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long black candle
                LowerShadow(ohlcv1) > longShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long lower shadow
                RealBody(ohlcv3) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: small
            {
                double veryShort = veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3);
                if (LowerShadow(ohlcv3) < veryShort && // 3rd: very short lower shadow
                    UpperShadow(ohlcv3) < veryShort) // 3rd: very short upper shadow
                    return 100;
            }
            return 0;
            //return (
            //    IsBlack(ohlcv1) && // 1st: black
            //    IsBlack(ohlcv2) && // 2nd: black
            //    IsBlack(ohlcv3) && // 3rd: black
            //    RealBody(ohlcv2) < RealBody(ohlcv1) // 2nd: smaller black candle
            //    ohlcv2.Open > ohlcv1.Close && ohlcv2.Open <= ohlcv1.High && // 2nd: opens higher than prior close but within prior candle's range
            //    ohlcv2.Low < ohlcv1.Close && ohlcv2.Low >= ohlcv1.Low && // 2nd: trades lower than prior close but not lower than prior low and closes off of its low
            //    LowerShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: has a lower shadow
            //    RealBody(ohlcv1) < longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long black candle
            //    LowerShadow(ohlcv1) > longShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long lower shadow
            //    RealBody(ohlcv3) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: small
            //    LowerShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: very short lower shadow
            //    UpperShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: very short upper shadow
            //    ohlcv3.Low > ohlcv2.Low && ohlcv3.High < ohlcv2.High // 3rd: engulfed by prior candle's range
            //    ) ? 100 : 0;
        }
    }
}
