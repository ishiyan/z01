﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Harami pattern.
        /// </summary>
        public const int HaramiCandlesticks = 2;

        /// <summary>
        /// The Harami pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Harami(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HaramiCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long white (black) real body,
            // - second candle: short real body totally engulfed by the first,
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that a harami is significant when it appears in a downtrend if bullish or
            // in an uptrend when bearish, while this function does not consider the trend.


            if (IsWhite(ohlcv1) && // 1st: white
                Math.Max(ohlcv2.Close, ohlcv2.Open) < Math.Max(ohlcv1.Close, ohlcv1.Open) && // 2nd: engulfed by 1st
                Math.Min(ohlcv2.Close, ohlcv2.Open) > Math.Min(ohlcv1.Close, ohlcv1.Open) && // 2nd: engulfed by 1st
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: short real body
                return -100;

            if (IsBlack(ohlcv1) && // 1st: black
                Math.Max(ohlcv2.Close, ohlcv2.Open) < Math.Max(ohlcv1.Close, ohlcv1.Open) && // 2nd: engulfed by 1st
                Math.Min(ohlcv2.Close, ohlcv2.Open) > Math.Min(ohlcv1.Close, ohlcv1.Open) && // 2nd: engulfed by 1st
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: short real body
                return 100;

            return 0;
        }
    }
}
