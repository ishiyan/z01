﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Counterattack pattern.
        /// </summary>
        public const int CounterattackCandlesticks = 2;

        /// <summary>
        /// The Counterattack pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Counterattack(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - CounterattackCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black (white),
            // - second candle: long white (black) with close equal to the prior close.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that a counterattack is significant in a trend, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                BlackRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                WhiteRealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: long real body
            {
                double equal = equalCriterion.AverageValue(ohlcvList, 2, ohlcv1);
                if (ohlcv2.Close <= ohlcv1.Close + equal && // equal closes
                    ohlcv2.Close >= ohlcv1.Close - equal)
                    return 100;
                return 0;
            }

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                BlackRealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: long real body
            {
                double equal = equalCriterion.AverageValue(ohlcvList, 2, ohlcv1);
                if (ohlcv2.Close <= ohlcv1.Close + equal && // equal closes
                    ohlcv2.Close >= ohlcv1.Close - equal)
                    return -100;
                return 0;
            }

            return 0;
        }
    }
}
