using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ShortLine pattern.
        /// </summary>
        public const int ShortLineCandlesticks = 1;

        /// <summary>
        /// The ShortLine pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ShortLine(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ShortLineCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < shortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv = ohlcvList[count];

            // Must have:
            // - short real body,
            // - short upper and lower shadow.
            // Output is positive (1 to 100) when white, negative (-1 to -100) when black.
            // it does not mean bullish or bearish.

            if (RealBody(ohlcv) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv)) // short real body
            {
                double value = shortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv);
                if (UpperShadow(ohlcv) < value && LowerShadow(ohlcv) < value) // short upper and lower shadow
                {
                    if (IsWhite(ohlcv))
                        return 100;
                    if (IsBlack(ohlcv))
                        return -100;
                }
            }
            return 0;
        }
    }
}
