﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Takuri pattern.
        /// </summary>
        public const int TakuriCandlesticks = 1;

        /// <summary>
        /// The Takuri pattern (Dragonfly Doji with very long lower shadow).
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Takuri(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - TakuriCandlesticks;
            if (count < veryLongShadowCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count];

            // Must have:
            // - doji body,
            // - open and close at the high of the day = no or very short upper shadow,
            // - very long lower shadow.
            // Output is always positive (1 to 100) but this does not mean it is bullish: takuri must be considered relatively to the trend.

            if (RealBody(ohlcv1) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1) && // doji
                UpperShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1) && // no or very short upper shadow
                LowerShadow(ohlcv1) > veryLongShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // very long lower shadow
                return 100;

            return 0;
        }
    }
}
