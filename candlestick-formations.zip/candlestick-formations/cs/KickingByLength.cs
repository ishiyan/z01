﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the KickingByLength (bull/bear determined by the longer marubozu) pattern.
        /// </summary>
        public const int KickingByLengthCandlesticks = 2;

        /// <summary>
        /// The KickingByLength (bull/bear determined by the longer marubozu) pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int KickingByLength(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - KickingByLengthCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: marubozu,
            // - second candle: opposite color marubozu,
            // - gap between the two candles: upside gap if black then white, downside gap if white then black,
            // - the size of two real bodies should be near the same.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The longer of the two marubozu determines the bullishness or bearishness of this pattern.

            if ((IsWhite(ohlcv1) && IsBlack(ohlcv2)) || // 1st: white, 2nd: black
                (IsBlack(ohlcv1) && IsWhite(ohlcv2))) // 1st: black, 2nd: white
            {
                if (RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: marubozu
                    RealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: marubozu
                {
                    double shadow = veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv1);
                    if (UpperShadow(ohlcv1) < shadow && LowerShadow(ohlcv1) < shadow) // 1st: marubozu
                    {
                        shadow = veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2);
                        if (UpperShadow(ohlcv2) < shadow && LowerShadow(ohlcv2) < shadow) // 2nd: marubozu
                        {
                            if (IsRealBodyGapDown(ohlcv1, ohlcv2) || // 2nd: gapping down
                                IsRealBodyGapUp(ohlcv1, ohlcv2)) // 2nd: gapping up
                            {
                                bool isBullish = RealBody(ohlcv2) > RealBody(ohlcv1) ? IsWhite(ohlcv2) : IsWhite(ohlcv1);
                                return isBullish ? 100 : -100;
                            }
                        }
                    }
                }
            }

            return 0;
        }
    }
}
