﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the MorningStar pattern.
        /// </summary>
        public const int MorningStarCandlesticks = 3;

        /// <summary>
        /// Specifies the meaning of "moves well within" for a morning star pattern.
        /// The value must be in range [0, 3e+37], the default value is 0.3.
        /// </summary>
        public double MorningStarPenetrationFactor = 0.3;

        /// <summary>
        /// The MorningStar pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int MorningStar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - MorningStarCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long black real body,
            // - second candle: star (short real body gapping down),
            // - third candle: white real body that moves well within the first candle's real body.
            // The meaning of "moves well within" is specified with MorningStarPenetrationFactor
            // and "moves" should mean the real body should not be short - Greg Morris wants it to be long,
            // someone else want it to be relatively long.
            // Output is positive (1 to 100): advancing morning star is always bullish.
            // The user should consider that morning star is significant when it appears in a downtrend, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv1.Close + RealBody(ohlcv1) * MorningStarPenetrationFactor && // 3rd: moves well within first candle's real body
                IsRealBodyGapDown(ohlcv1, ohlcv2) && // 2nd: gapping down
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short
                RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: longer than short
                return 100;

            return 0;
        }
    }
}
