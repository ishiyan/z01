﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Stalled pattern.
        /// </summary>
        public const int StalledCandlesticks = 3;

        /// <summary>
        /// The Stalled pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Stalled(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - StalledCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - three white candlesticks with consecutively higher closes;
            // - first candle: long white;
            // - second candle: long white with no or very short upper shadow opening within or near the previous white real body and closing higher than the prior candle;
            // - third candle: small white that gaps away or "rides on the shoulder" of the prior long real body (= it's at the upper end of the prior real body).
            // The output is negative (-1 to -100): stalled pattern is always bearish.
            // The user should consider that stalled pattern is significant when it appears in an uptrend, while this function 
            // does not consider the trend.

            return (
                IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv2.Close && ohlcv2.Close > ohlcv1.Close && // consecutive higher closes
                ohlcv2.Open > ohlcv1.Open && // 2nd: opens within/near 1st real body
                ohlcv2.Open <= ohlcv1.Close + nearCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: opens within/near 1st real body
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                WhiteRealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: long real body
                WhiteUpperShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short upper shadow
                WhiteRealBody(ohlcv3) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: short real body
                ohlcv3.Open >= ohlcv2.Close - WhiteRealBody(ohlcv3) - nearCriterion.AverageValue(ohlcvList, 2, ohlcv2) // rides on the shoulder of 2nd real body
                ) ? -100 : 0;
        }
    }
}
