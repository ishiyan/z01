﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the LadderBottom pattern.
        /// </summary>
        public const int LadderBottomCandlesticks = 5;

        /// <summary>
        /// The LadderBottom pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int LadderBottom(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - LadderBottomCandlesticks;
            if (count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count], ohlcv5 = ohlcvList[++count];

            // Must have:
            // - three black candlesticks with consecutively lower opens and closes;
            // - fourth candle: black candle with an upper shadow (it's supposed to be not very short);
            // - fifth candle: white candle that opens above prior candle's body and closes above prior candle's high.
            // The output is positive (1 to 100): ladder bottom is always bullish.
            // The user should consider that ladder bottom pattern is significant when it appears in an downtrend, while this function 
            // does not consider the trend.

            return (
                IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                IsBlack(ohlcv4) && // 4th: black
                IsWhite(ohlcv5) && // 5th: white
                ohlcv1.Open > ohlcv2.Open && ohlcv2.Open > ohlcv3.Open && // first three: with consecutively lower opens
                ohlcv1.Close > ohlcv2.Close && ohlcv2.Close > ohlcv3.Close && // first three: with consecutively lower and closes
                ohlcv5.Open > ohlcv4.Open && // 5th: opens above prior candle's body
                ohlcv5.Close > ohlcv4.High && // 5th: closes above prior candle's high
                BlackUpperShadow(ohlcv4) > veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv4) // 4th: with an upper shadow
                ) ? 100 : 0;
        }
    }
}
