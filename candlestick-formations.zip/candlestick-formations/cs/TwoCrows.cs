﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the TwoCrows pattern.
        /// </summary>
        public const int TwoCrowsCandlesticks = 3;

        /// <summary>
        /// The <c>(Upside Gap) Two Crows</c> is a three day bearish pattern that only happens in an uptrend.
        /// <para/>
        /// The first day is a long white body followed by a gapped open with the small black body remaining gapped above the first day.
        /// <para/>
        /// The third day is also a black day whose body is larger than the second day and engulfs it.
        /// <para/>
        /// The close of the last day is still above the first long white day.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int TwoCrows(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - TwoCrowsCandlesticks;
            if (0 > count - longRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candlestick: long white;
            // - second candlestick: black real body;
            // - gap between the first and the second candlestick's real bodies;
            // - third candlestick: black candlestick that opens within the second real body and closes within the first real body.
            // The output is negative (0 to -100): two crows is always bearish.
            // The user should consider that two crows is significant when it appears in an uptrend, while this function 
            // does not consider the trend.

            bool b1 = IsWhite(ohlcv1);
            bool b2 = IsBlack(ohlcv2);
            bool b3 = IsBlack(ohlcv3);
            bool b4 = IsRealBodyGapUp(ohlcv1, ohlcv2);
            bool b5 = ohlcv3.Open < ohlcv2.Open && ohlcv3.Open > ohlcv2.Close; // IsRealBodyEnclosesOpen(ohlcv2, ohlcv3);
            bool b6 = ohlcv3.Close > ohlcv1.Open && ohlcv3.Close < ohlcv1.Close; // IsRealBodyEnclosesClose(ohlcv1, ohlcv3);
            double d1 = WhiteRealBody(ohlcv1);
            double d2 = longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1);
            bool b7 = d1 > d2;

            return (
                IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv3.Open < ohlcv2.Open && ohlcv3.Open > ohlcv2.Close && // 3rd: opening within 2nd real body
                ohlcv3.Close > ohlcv1.Open && ohlcv3.Close < ohlcv1.Close && // 3rd: closing within 1st real body
                //IsRealBodyEnclosesOpen(ohlcv2, ohlcv3) && // 3rd: opening within 2nd real body
                //IsRealBodyEnclosesClose(ohlcv1, ohlcv3) && // 3rd: closing within 1st real body
                IsRealBodyGapUp(ohlcv1, ohlcv2) &&  // 2nd: gapping up
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) // 1st: long
                ) ? -100 : 0;
        }
    }
}
