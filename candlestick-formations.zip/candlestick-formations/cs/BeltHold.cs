﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the BeltHold pattern.
        /// </summary>
        public const int BeltHoldCandlesticks = 1;

        /// <summary>
        /// The BeltHold pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int BeltHold(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - BeltHoldCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv = ohlcvList[count];

            // Must have:
            // - long white (black) real body,
            // - no or very short lower (upper) shadow,
            // Output is positive (1 to 100) (1 to 100) when white (bullish), negative (-1 to -100) when black (bearish).

            if (RealBody(ohlcv) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv)) // long real body
            {
                double veryShortShadow = veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv);
                if (IsWhite(ohlcv) && // white
                    LowerShadow(ohlcv) < veryShortShadow) // very short lower shadow
                    return 100;

                if (IsBlack(ohlcv) && // black
                    UpperShadow(ohlcv) < veryShortShadow) // very short upper shadow
                    return -100;
            }
            return 0;
        }
    }
}
