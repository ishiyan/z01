﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Breakaway pattern.
        /// </summary>
        public const int BreakawayCandlesticks = 5;

        /// <summary>
        /// The Breakaway pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Breakaway(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - BreakawayCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count], ohlcv5 = ohlcvList[++count];

            // Must have:
            // - first candle: long black (white),
            // - second candle: black (white) day whose body gaps down (up),
            // - third candle: black or white day with lower (higher) high and lower (higher) low than prior candle's,
            // - fourth candle: black (white) day with lower (higher) high and lower (higher) low than prior candle's,
            // - fifth candle: white (black) day that closes inside the gap, erasing the prior 3 days.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that breakaway is significant in a trend opposite to the last candle, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv4) && // 4th: black
                IsWhite(ohlcv5) && // 5th: white
                ohlcv3.High < ohlcv2.High && ohlcv3.Low < ohlcv2.Low && // 3rd: has lower high and low than 2nd
                ohlcv4.High < ohlcv3.High && ohlcv4.Low < ohlcv3.Low && // 4th: has lower high and low than 3rd
                ohlcv5.Close > ohlcv2.Open && ohlcv5.Close < ohlcv1.Close && // 5th: closes inside the gap
                IsRealBodyGapDown(ohlcv1, ohlcv2) && // 2nd: gaps up
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1)) // 1st: long real body
                return 100;

            if (IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv4) && // 4th: white
                IsBlack(ohlcv5) && // 5th: black
                ohlcv3.High > ohlcv2.High && ohlcv3.Low > ohlcv2.Low && // 3rd: has higher high and low than 2nd
                ohlcv4.High > ohlcv3.High && ohlcv4.Low > ohlcv3.Low && // 4th: has higher high and low than 3rd
                ohlcv5.Close < ohlcv2.Open && ohlcv5.Close > ohlcv1.Close && // 5th: closes inside the gap
                IsRealBodyGapUp(ohlcv1, ohlcv2) && // 2nd: gaps down
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1)) // 1st: long real body
                return -100;

            return 0;
        }

        /// <summary>
        /// The bullish Breakaway pattern.
        /// </summary>
        public bool BreakawayBullish(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - BreakawayCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count++], ohlcv2 = ohlcvList[count++], ohlcv3 = ohlcvList[count++], ohlcv4 = ohlcvList[count++], ohlcv5 = ohlcvList[count];

            // Must have:
            // - first candle: long black (white),
            // - second candle: black (white) day whose body gaps down (up),
            // - third candle: black or white day with lower (higher) high and lower (higher) low than prior candle's,
            // - fourth candle: black (white) day with lower (higher) high and lower (higher) low than prior candle's,
            // - fifth candle: white (black) day that closes inside the gap, erasing the prior 3 days.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that breakaway is significant in a trend opposite to the last candle, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv4) && // 4th: black
                IsWhite(ohlcv5) && // 5th: white
                ohlcv3.High < ohlcv2.High && ohlcv3.Low < ohlcv2.Low && // 3rd: has lower high and low than 2nd
                ohlcv4.High < ohlcv3.High && ohlcv4.Low < ohlcv3.Low && // 4th: has lower high and low than 3rd
                ohlcv5.Close > ohlcv2.Open && ohlcv5.Close < ohlcv1.Close && // 5th: closes inside the gap
                IsRealBodyGapDown(ohlcv1, ohlcv2) && // 2nd: gaps up
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1)) // 1st: long real body
                return true;

            return false;
       }

        /// <summary>
        /// The bearish Breakaway pattern.
        /// </summary>
        public bool BreakawayBearish(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - BreakawayCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count++], ohlcv2 = ohlcvList[count++], ohlcv3 = ohlcvList[count++], ohlcv4 = ohlcvList[count++], ohlcv5 = ohlcvList[count];

            // Must have:
            // - first candle: long black (white),
            // - second candle: black (white) day whose body gaps down (up),
            // - third candle: black or white day with lower (higher) high and lower (higher) low than prior candle's,
            // - fourth candle: black (white) day with lower (higher) high and lower (higher) low than prior candle's,
            // - fifth candle: white (black) day that closes inside the gap, erasing the prior 3 days.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that breakaway is significant in a trend opposite to the last candle, while this function does not consider it.

            if (IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv4) && // 4th: white
                IsBlack(ohlcv5) && // 5th: black
                ohlcv3.High > ohlcv2.High && ohlcv3.Low > ohlcv2.Low && // 3rd: has higher high and low than 2nd
                ohlcv4.High > ohlcv3.High && ohlcv4.Low > ohlcv3.Low && // 4th: has higher high and low than 3rd
                ohlcv5.Close < ohlcv2.Open && ohlcv5.Close > ohlcv1.Close && // 5th: closes inside the gap
                IsRealBodyGapUp(ohlcv1, ohlcv2) && // 2nd: gaps down
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1)) // 1st: long real body
                return true;

            return false;
       }
    }
}
