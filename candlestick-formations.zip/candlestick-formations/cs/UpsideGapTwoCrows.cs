﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the UpsideGapTwoCrows pattern.
        /// </summary>
        public const int UpsideGapTwoCrowsCandlesticks = 3;

        /// <summary>
        /// The UpsideGapTwoCrows pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int UpsideGapTwoCrows(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - UpsideGapTwoCrowsCandlesticks;
            if (0 > count - longRealBodyCriterion.AveragePeriod ||
                0 > count - shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: white candle, usually long;
            // - second candle: small black real body;
            // - gap between the first and the second candle's real bodies;
            // - third candle: black candle with a real body that engulfs the preceding candle and closes above the white candle's close.
            // The output is negative (-1 to -100): upside gap two crows is always bearish. 
            // The user should consider that upside gap two crows is significant when it appears in an uptrend, while this function 
            // does not consider the trend.

            return (
                IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv3.Close > ohlcv1.Close && // 3rd: closing above 1st
                ohlcv3.Open > ohlcv2.Open && ohlcv3.Close < ohlcv2.Close && // 3rd: engulfing prior real body
                IsRealBodyGapUp(ohlcv1, ohlcv2) &&  // 2nd: gapping up
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long
                BlackRealBody(ohlcv2) < shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) // 2nd: short
                ) ? -100 : 0;
        }
    }
}
