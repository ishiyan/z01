﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Tristar pattern.
        /// </summary>
        public const int TristarCandlesticks = 3;

        /// <summary>
        /// The Tristar pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Tristar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - TristarCandlesticks;
            if (count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - 3 consecutive doji days,
            // - the second doji is a star.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.

            if (RealBody(ohlcv1) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: doji
                RealBody(ohlcv2) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: doji
                RealBody(ohlcv3) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3))   // 3rd: doji
            {
                if (IsRealBodyGapUp(ohlcv1, ohlcv2) && // 2nd gaps up
                    Math.Max(ohlcv3.Open, ohlcv3.Close) < Math.Max(ohlcv2.Open, ohlcv2.Close)) // 3rd is not higher than 2nd
                    return -100;

                if (IsRealBodyGapDown(ohlcv1, ohlcv2) && // 2nd gaps down
                    Math.Min(ohlcv3.Open, ohlcv3.Close) > Math.Min(ohlcv2.Open, ohlcv2.Close)) // 3rd is not lower than 2nd
                    return 100;
            }

            return 0;
        }
    }
}
