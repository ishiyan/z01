﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the DragonflyDoji pattern.
        /// </summary>
        public const int DragonflyDojiCandlesticks = 1;

        /// <summary>
        /// The DragonflyDoji pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int DragonflyDoji(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - DragonflyDojiCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count];

            // Must have:
            // - doji body,
            // - open and close at the high of the day, that is no or very short upper shadow,
            // - lower shadow (to distinguish from other dojis, here lower shadow should not be very short).
            // Output is always positive (1 to 100) but this does not mean it is bullish:
            // dragonfly doji must be considered relatively to the trend.

            double veryShort = veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1);

            if (UpperShadow(ohlcv1) < veryShort && // 1st: no or very short upper shadow
                LowerShadow(ohlcv1) > veryShort && // 1st: lower shadow is not very short
                RealBody(ohlcv1) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // 1st: doji
                return 100;

            return 0;
        }
    }
}
