﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the HighWave pattern.
        /// </summary>
        public const int HighWaveCandlesticks = 1;

        /// <summary>
        /// The HighWave pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HighWave(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HighWaveCandlesticks;
            if (count < veryLongShadowCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count];

            // Must have:
            // - short real body,
            // - very long upper and lower shadow,
            // Output positive (1 to 100) when white or negative (-1 to -100) when black; it does not mean bullish or bearish.

            double veryLongShadow = veryLongShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1);

            if (IsWhite(ohlcv1) && // white candle
                UpperShadow(ohlcv1) > veryLongShadow && // very long upper shadow
                LowerShadow(ohlcv1) > veryLongShadow && // very long lower shadow
                RealBody(ohlcv1) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // short real body
                return 100;

            if (IsBlack(ohlcv1) && // black candle
                UpperShadow(ohlcv1) > veryLongShadow && // very long upper shadow
                LowerShadow(ohlcv1) > veryLongShadow && // very long lower shadow
                RealBody(ohlcv1) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // short real body
                return -100;

            return 0;
        }
    }
}
