﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Hammer pattern.
        /// </summary>
        public const int HammerCandlesticks = 2;

        /// <summary>
        /// The Hammer pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Hammer(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HammerCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv0 = ohlcvList[count], ohlcv1 = ohlcvList[++count];

            // Must have:
            // - small real body,
            // - long lower shadow,
            // - no, or very short, upper shadow,
            // - body below or near the lows of the previous candle.
            // Output is positive (1 to 100): hammer is always bullish.
            // The user should consider that a hammer must appear in a downtrend, while this function does not consider it.

            return (
                RealBody(ohlcv1) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1) && // small real body
                LowerShadow(ohlcv1) > longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1) && // long lower shadow
                UpperShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1) && // no, or very short, upper shadow
                Math.Min(ohlcv1.Open, ohlcv1.Close) <= ohlcv0.Low + nearCriterion.AverageValue(ohlcvList, 1, ohlcv1) // body below or near the lows of the previous candle
                ) ? 100 : 0;
        }
    }
}
