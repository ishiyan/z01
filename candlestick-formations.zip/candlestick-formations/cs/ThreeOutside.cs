﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ThreeOutside pattern.
        /// </summary>
        public const int ThreeOutsideCandlesticks = 3;

        /// <summary>
        /// Three Outside Up/Down.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ThreeOutside(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeOutsideCandlesticks;
            if (count < 0)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: black (white) real body,
            // - second candle: white (black) real body that engulfs the prior real body,
            // - third candle: closes higher (lower) than the second candle.
            // The output is positive (1 to 100) for the three outside up or negative (-1 to -100) for the three outside down; 
            // the user should consider that a three outside up must appear in a downtrend and a three outside
            // down must appear in an uptrend, while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1) && // 1st: real body totally engulfed by the 2nd's real body
                ohlcv3.Close > ohlcv2.Close) // 3rd: closes higher than the 2nd candle
                return 100; // up

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 2rd: black
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1) && // 1st: real body totally engulfed by the 2nd's real body
                ohlcv3.Close < ohlcv2.Close) // 3rd: closes lower than the 2nd candle
                return -100; // down

            return 0;
        }

        /// <summary>
        /// Three Outside Up.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if there is a match.</returns>
        public bool ThreeOutsideUp(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeOutsideCandlesticks;
            if (count < 0)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: black real body,
            // - second candle: white real body that engulfs the prior real body,
            // - third candle: closes higher than the second candle.
            // The output is positive (1 to 100) for the three outside up;
            // the user should consider that a three outside up must appear in a downtrend,
            // while this function does not consider the trend.

            return (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1) && // 1st: real body totally engulfed by the 2nd's real body
                ohlcv3.Close > ohlcv2.Close); // 3rd: closes higher than the 2nd candle
        }

        /// <summary>
        /// Three Outside Down.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if there is a match.</returns>
        public bool ThreeOutsideDown(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeOutsideCandlesticks;
            if (count < 0)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: white real body,
            // - second candle: black real body that engulfs the prior real body,
            // - third candle: closes lower than the second candle.
            // The output is negative (-1 to -100) for the three outside down; 
            // the user should consider that a three outside down must appear in an uptrend,
            // while this function does not consider the trend.

            return (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 2rd: black
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1) && // 1st: real body totally engulfed by the 2nd's real body
                ohlcv3.Close < ohlcv2.Close); // 3rd: closes lower than the 2nd candle
        }
    }
}
