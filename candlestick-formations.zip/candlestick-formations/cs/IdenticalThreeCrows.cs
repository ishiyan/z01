﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the IdenticalThreeCrows pattern.
        /// </summary>
        public const int IdenticalThreeCrowsCandlesticks = 3;

        /// <summary>
        /// The IdenticalThreeCrows pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int IdenticalThreeCrows(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - IdenticalThreeCrowsCandlesticks;
            if (0 > count - veryShortShadowCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - three consecutive and declining black candlesticks,
            // - each candle must have no or very short lower shadow,
            // - each candle after the first must open at or very close to the prior candle's close.
            // Output is negative (-1 to -100): identical three crows are always bearish.
            // The user should consider that identical 3 crows are significant when appear after a mature advance
            // or at high levels, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv1.Close > ohlcv2.Close && // three declining
                ohlcv2.Close > ohlcv3.Close) // three declining
            {
                double equal1 = equalCriterion.AverageValue(ohlcvList, 3, ohlcv1);
                double equal2 = equalCriterion.AverageValue(ohlcvList, 2, ohlcv2);
                if (ohlcv2.Open <= ohlcv1.Close + equal1 && ohlcv2.Open >= ohlcv1.Close - equal1 && // 2nd: opens very close to 1st close
                    ohlcv3.Open <= ohlcv2.Close + equal2 && ohlcv3.Open >= ohlcv2.Close - equal2 && // 3rd: opens very close to 2nd close
                    BlackLowerShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: very short lower shadow
                    BlackLowerShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short lower shadow
                    BlackLowerShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: very short lower shadow
                    return -100;
            }

            return 0;
        }
    }
}
