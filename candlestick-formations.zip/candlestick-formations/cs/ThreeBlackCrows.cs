﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ThreeBlackCrows pattern.
        /// </summary>
        public const int ThreeBlackCrowsCandlesticks = 4;

        /// <summary>
        /// A bearish reversal pattern consisting of the three consecutive black bodies where each day closes near below the previous low and opens within the body of the previous day.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ThreeBlackCrows(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeBlackCrowsCandlesticks;
            if (0 > count - veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv0 = ohlcvList[count], ohlcv1 = ohlcvList[++count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - three consecutive and declining black candlesticks
            // - each candlestick must have no or very short lower shadow
            // - each candlestick after the first must open within the prior candlestick's real body
            // - the first candlestick's close should be under the prior white candlestick's high
            // Output is negative (-1 to -100): three black crows are always bearish; 
            // the user should consider that 3 black crows is significant when it appears after a mature advance
            // or at high levels,  while this function does not consider it.

            return (
                IsWhite(ohlcv0) && // preceeding: white
                IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv1.Close > ohlcv2.Close && // three declining
                ohlcv2.Close > ohlcv3.Close && // three declining
                IsHighExceedsClose(ohlcv0, ohlcv1) && // 1st: closing under preceeding high
                IsRealBodyEnclosesOpen(ohlcv1, ohlcv2) && // 2nd: opening within 1nd real body
                IsRealBodyEnclosesOpen(ohlcv2, ohlcv3) && // 3rd: opening within 2nd real body
                BlackLowerShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: very short lower shadow
                BlackLowerShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short lower shadow
                BlackLowerShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) // 3rd: very short lower shadow
                ) ? -100 : 0;
        }
    }
}
