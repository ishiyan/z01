﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Three-Line Strike pattern.
        /// </summary>
        public const int ThreeLineStrikeCandlesticks = 4;

        /// <summary>
        /// Three-Line Strike.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ThreeLineStrike(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeLineStrikeCandlesticks;
            if (0 > count - nearCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count];

            // Must have:
            // - three white soldiers (three black crows): three white (black) candlesticks with consecutively higher (lower) closes, each opening within or near the previous real body;
            // - fourth candle: black (white) candle that opens above (below) prior candle's close and closes below (above) the first candle's open.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish;
            // the user should consider that 3-line strike is significant when it appears in a trend in the same direction of
            // the first three candles, while this function does not consider it.

            if (IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 1nd: white
                IsWhite(ohlcv3) && // 3rd: white
                IsBlack(ohlcv4) && // 4th: black
                ohlcv1.Close < ohlcv2.Close && ohlcv2.Close < ohlcv3.Close && // 1st, 2nd, 3rd: consecutive higher closes
                ohlcv3.Close < ohlcv4.Open && // 4th opens above 3rd's close
                ohlcv1.Open > ohlcv4.Close && // 4th closes below 1st's open
                IsOpensWithin(ohlcv2, ohlcv1, nearCriterion.AverageValue(ohlcvList, 4, ohlcv1)) && // 2nd: opens within or near 1st real body
                IsOpensWithin(ohlcv3, ohlcv2, nearCriterion.AverageValue(ohlcvList, 3, ohlcv2))) // 3rd: opens within or near 2nd real body
                return 100;

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 1nd: black
                IsBlack(ohlcv3) && // 3rd: black
                IsWhite(ohlcv4) && // 4th: white
                ohlcv1.Close > ohlcv2.Close && ohlcv2.Close > ohlcv3.Close && // 1st, 2nd, 3rd: consecutive lower closes
                ohlcv3.Close > ohlcv4.Open && // 4th opens below 3rd's close
                ohlcv1.Open < ohlcv4.Close && // 4th closes above 1st's open
                IsOpensWithin(ohlcv2, ohlcv1, nearCriterion.AverageValue(ohlcvList, 4, ohlcv1)) && // 2nd: opens within or near 1st real body
                IsOpensWithin(ohlcv3, ohlcv2, nearCriterion.AverageValue(ohlcvList, 3, ohlcv2))) // 3rd: opens within or near 2nd real body
                return -100;

            return 0;
        }
    }
}
