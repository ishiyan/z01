﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// Specifies a criterion based on the average value of a certain part of a candlestick multiplied by a certain factor.
    /// The criteria are based on the parts of the candlestick and the common words indicating the length (short, long, very long), the displacement (near, far) or equality (equal).
    /// </summary>
    public class Criterion
    {
        #region Construction
        /// <summary>
        /// Constructs a new instance of this class.
        /// </summary>
        /// <param name="entity">A type of the range entity to consider.</param>
        /// <param name="averagePeriod">A number of previous candlesticks to calculate an average value of the <paramref name="entity"/>.</param>
        /// <param name="factor">A coefficient to multiply an average value of the <paramref name="entity"/>.</param>
        public Criterion(RangeEntity entity, int averagePeriod, double factor)
        {
            Entity = entity;
            AveragePeriod = averagePeriod;
            Factor = factor;
        }

        /// <summary>
        /// Copy constructor. Constructs a new instance of this class.
        /// </summary>
        /// <param name="other">An other instance of the class.</param>
        public Criterion(Criterion other)
        {
            Entity = other.Entity;
            AveragePeriod = other.AveragePeriod;
            Factor = other.Factor;
        }
        #endregion

        #region Entity
        /// <summary>
        /// A type of the range entity to consider.
        /// </summary>
        public readonly RangeEntity Entity;
        #endregion

        #region AveragePeriod
        /// <summary>
        /// A number of previous candlesticks to calculate an average value of the range entity.
        /// </summary>
        public readonly int AveragePeriod;
        #endregion

        #region Factor
        /// <summary>
        /// A coefficient to multiply an average value of the range entity.
        /// </summary>
        public readonly double Factor;
        #endregion

        #region AverageValue
        /// <summary>
        /// An average value of the criterion.
        /// </summary>
        /// <param name="totalValue">The total value.</param>
        /// <param name="ohlcv">The candlestick.</param>
        /// <returns>An average value of the criterion.</returns>
        public double AverageValue(double totalValue, Ohlcv ohlcv)
        {
            if (0d < AveragePeriod)
            {
                if (RangeEntity.Shadows == Entity)
                    return Factor * totalValue / (AveragePeriod * 2d);
                return Factor * totalValue / AveragePeriod;
            }

            if (RangeEntity.RealBody == Entity)
                return Factor * (ohlcv.IsRising ? (ohlcv.Close - ohlcv.Open) : (ohlcv.Open - ohlcv.Close));

            if (RangeEntity.HighLow == Entity)
                return Factor * (ohlcv.High - ohlcv.Low);

            //if (RangeEntity.Shadows == Entity)
            if (ohlcv.IsRising)
                return Factor * (ohlcv.High - ohlcv.Close + ohlcv.Open - ohlcv.Low) / 2d;
            return Factor * (ohlcv.High - ohlcv.Open + ohlcv.Close - ohlcv.Low) / 2d;
        }

        /// <summary>
        /// An average value of the criterion.
        /// </summary>
        /// <param name="ohlcvList">The list of candlesticks.</param>
        /// <param name="shift">The shift from the end of the list.</param>
        /// <param name="otherOhlcv">The candlestick in question.</param>
        /// <returns>An average value of the criterion.</returns>
        public double AverageValue(List<Ohlcv> ohlcvList, int shift, Ohlcv otherOhlcv)
        {
            if (0d < AveragePeriod)
            {
                double value = 0d;
                int count = ohlcvList.Count - shift, i = count - AveragePeriod;
                if (0 <= i)
                {
                    Ohlcv ohlcv;
                    if (RangeEntity.RealBody == Entity)
                    {
                        while (i < count)
                        {
                            ohlcv = ohlcvList[i++];
                            value += (ohlcv.IsRising ? (ohlcv.Close - ohlcv.Open) : (ohlcv.Open - ohlcv.Close));
                        }
                    }
                    else if (RangeEntity.HighLow == Entity)
                    {
                        while (i < count)
                        {
                            ohlcv = ohlcvList[i++];
                            value += ohlcv.High - ohlcv.Low;
                        }
                    }
                    else //if (RangeEntity.Shadows == Entity)
                    {
                        while (i < count)
                        {
                            ohlcv = ohlcvList[i++];
                            if (ohlcv.IsRising)
                                value += ohlcv.High - ohlcv.Close + ohlcv.Open - ohlcv.Low;
                            else
                                value += ohlcv.High - ohlcv.Open + ohlcv.Close - ohlcv.Low;
                        }
                        value /= 2d;
                    }
                    value *= Factor / AveragePeriod;
                }
                return value;
            }

            if (RangeEntity.RealBody == Entity)
                return Factor * (otherOhlcv.IsRising ? (otherOhlcv.Close - otherOhlcv.Open) : (otherOhlcv.Open - otherOhlcv.Close));

            if (RangeEntity.HighLow == Entity)
                return Factor * (otherOhlcv.High - otherOhlcv.Low);

            //if (RangeEntity.Shadows == Entity)
            if (otherOhlcv.IsRising)
                return Factor * (otherOhlcv.High - otherOhlcv.Close + otherOhlcv.Open - otherOhlcv.Low) / 2d;
            return Factor * (otherOhlcv.High - otherOhlcv.Open + otherOhlcv.Close - otherOhlcv.Low) / 2d;
        }
        #endregion

        #region Total
        /// <summary>
        /// A total value of the criterion.
        /// </summary>
        /// <param name="ohlcvList">The list of candlesticks.</param>
        /// <param name="shift">The shift from the end of the list.</param>
        /// <returns>A total value of the criterion.</returns>
        public double TotalValue(List<Ohlcv> ohlcvList, int shift)
        {
            double value = 0d;
            int count = ohlcvList.Count - shift, i = count - AveragePeriod;
            if (0 <= i)
            {
                Ohlcv ohlcv;
                if (RangeEntity.RealBody == Entity)
                {
                    while (i < count)
                    {
                        ohlcv = ohlcvList[i++];
                        value += (ohlcv.IsRising ? (ohlcv.Close - ohlcv.Open) : (ohlcv.Open - ohlcv.Close));
                    }
                }
                else if (RangeEntity.HighLow == Entity)
                {
                    while (i < count)
                    {
                        ohlcv = ohlcvList[i++];
                        value += ohlcv.High - ohlcv.Low;
                    }
                }
                else //if (RangeEntity.Shadows == Entity)
                {
                    while (i < count)
                    {
                        ohlcv = ohlcvList[i++];
                        if (ohlcv.IsRising)
                            value += ohlcv.High - ohlcv.Close + ohlcv.Open - ohlcv.Low;
                        else
                            value += ohlcv.High - ohlcv.Open + ohlcv.Close - ohlcv.Low;
                    }
                }
            }
            return value;
        }
        #endregion
    }
}
