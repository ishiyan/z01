﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the MatchingLow pattern.
        /// </summary>
        public const int MatchingLowCandlesticks = 2;

        /// <summary>
        /// The MatchingLow pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int MatchingLow(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - MatchingLowCandlesticks;
            if (count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: black candle,
            // - second candle: black candle with the close equal to the previous close.
            // Output is always positive (1 to 100): matching low is always bullish.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2)) // 2nd: black
            {
                double equal = equalCriterion.AverageValue(ohlcvList, 2, ohlcv1);
                if (ohlcv2.Close <= ohlcv1.Close + equal && ohlcv2.Close >= ohlcv1.Close - equal) // 1st and 2nd same close
                    return 100;
            }

            return 0;
        }
    }
}
