﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the UpDownGapSideBySideWhiteLines pattern.
        /// </summary>
        public const int UpDownGapSideBySideWhiteLinesCandlesticks = 3;

        /// <summary>
        /// The UpDownGapSideBySideWhiteLines pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int UpDownGapSideBySideWhiteLines(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - UpDownGapSideBySideWhiteLinesCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - upside or downside gap (between the bodies),
            // - first candle after the window: white candlestick,
            // - second candle after the window: white candlestick with similar size (near the same) and about the same open (equal) of the previous candle,
            // - the second candle does not close the window.
            // Output is positive (1 to 100) or negative (-1 to -100): the user should consider that upside
            // The user should consider that an evening star is significant when it appears in an uptrend,
            // or downside gap side-by-side white lines is significant when it appears in a trend,
            // while this function does not consider the trend.

            if (IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv3)) // 3rd: white
            {
                double secondBody = RealBody(ohlcv2);
                double secondNear = nearCriterion.AverageValue(ohlcvList, 2, ohlcv2);
                double secondEqual = equalCriterion.AverageValue(ohlcvList, 2, ohlcv2);
                if (IsRealBodyGapUp(ohlcv1, ohlcv2) && IsRealBodyGapUp(ohlcv1, ohlcv3) && // upside gap between the 1st candle and both the next 2 candles
                    RealBody(ohlcv3) >= secondBody - secondNear && // same size 2 and 3
                    RealBody(ohlcv3) <= secondBody + secondNear && // same size 2 and 3
                    ohlcv3.Open >= ohlcv2.Open - secondEqual && // same open 2 and 3
                    ohlcv3.Open <= ohlcv2.Open + secondEqual) // same open 2 and 3
                    return 100;

                if (IsRealBodyGapDown(ohlcv1, ohlcv2) && IsRealBodyGapDown(ohlcv1, ohlcv3) && // downside gap between the 1st candle and both the next 2 candles
                    RealBody(ohlcv3) >= secondBody - secondNear && // same size 2 and 3
                    RealBody(ohlcv3) <= secondBody + secondNear && // same size 2 and 3
                    ohlcv3.Open >= ohlcv2.Open - secondEqual && // same open 2 and 3
                    ohlcv3.Open <= ohlcv2.Open + secondEqual) // same open 2 and 3
                    return -100;
            }

            return 0;
        }
    }
}
