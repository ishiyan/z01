﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Unique3River pattern.
        /// </summary>
        public const int Unique3RiverCandlesticks = 3;

        /// <summary>
        /// The Unique3River pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Unique3River(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - Unique3RiverCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: black harami candle with a lower low than the first candle's low,
            // - third candle: small white candle with open not lower than the second candle's low,
            // better if its open and close are under the second candle's close.
            // Output is positive (1 to 100): unique 3 river is always bullish and should appear in a downtrend
            // to be significant, while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv2.Low < ohlcv1.Low && // 2nd: lower low
                ohlcv3.Open < ohlcv2.Low && // 3rd: open not lower
                ohlcv2.Close > ohlcv1.Close && ohlcv2.Open <= ohlcv1.Open && // 2nd: harami
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2)) // 2nd: short
                return 100;

            return 0;
        }
    }
}
