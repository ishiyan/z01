﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the XSideGapThreeMethods (upside/downside gap three methods) pattern.
        /// </summary>
        public const int XSideGapThreeMethodsCandlesticks = 3;

        /// <summary>
        /// The XSideGapThreeMethods (upside/downside gap three methods) pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int XSideGapThreeMethods(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - XSideGapThreeMethodsCandlesticks;
            if (count < 0)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: white (black) candle,
            // - second candle: white (black) candle,
            // - upside (downside) gap between the first and the second real bodies,
            // - third candle: black (white) candle that opens within the second real body and closes within the first real body.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that an up/downside gap 3 methods is significant when it appears in a trend,
            // while this function does not consider the trend.

            if (((IsWhite(ohlcv1) && IsWhite(ohlcv2) && IsBlack(ohlcv3)) || // 1st and 2nd white, 3rd black
                (IsBlack(ohlcv1) && IsBlack(ohlcv2) && IsWhite(ohlcv3))) && // 1st and 2nd black, 3rd white
                ohlcv3.Open < Math.Max(ohlcv2.Close, ohlcv2.Open) && // 3rd opens within 2nd real body
                ohlcv3.Open > Math.Min(ohlcv2.Close, ohlcv2.Open) &&
                ohlcv3.Close < Math.Max(ohlcv1.Close, ohlcv1.Open) && // 3rd closes within 1st real body
                ohlcv3.Close > Math.Min(ohlcv1.Close, ohlcv1.Open))
            {
                if (IsWhite(ohlcv1) && IsRealBodyGapUp(ohlcv1, ohlcv2)) // when 1st is white and upside gap
                    return 100;

                if (IsBlack(ohlcv1) && IsRealBodyGapDown(ohlcv1, ohlcv2)) // when 1st is black and downside gap
                    return -100;
            }

            return 0;
        }
    }
}
