﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the AdvanceBlock pattern.
        /// </summary>
        public const int AdvanceBlockCandlesticks = 3;

        /// <summary>
        /// The AdvanceBlock pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int AdvanceBlock(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - AdvanceBlockCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortShadowCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod ||
                count < farCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - three white candlesticks with consecutively higher closes,
            // - each candle opens within or near the previous white real body,
            // - first candle: long white with no or very short upper shadow (a short shadow is accepted too for more flexibility),
            // - second and third candles, or only third candle, show signs of weakening: progressively smaller white real bodies and/or relatively long upper shadows.
            // Output is negative (-1 to -100): advance block is always bearish.
            // The user should consider that advance block is significant when it appears in an uptrend, while this function does not consider it.

            //if (IsWhite(ohlcv1) && // 1st: white
            //    IsWhite(ohlcv2) && // 2nd: white
            //    IsWhite(ohlcv3) && // 3rd: white
            //    ohlcv3.Close > ohlcv2.Close && ohlcv2.Close > ohlcv1.Close && // consecutive higher closes
            //    ohlcv2.Open > ohlcv1.Open && ohlcv2.Open <= ohlcv1.Close + nearCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 2nd opens within/near 1st real body
            //    ohlcv3.Open > ohlcv2.Open && ohlcv3.Open <= ohlcv2.Close + nearCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 3rd opens within/near 2nd real body
            //    RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
            //    WhiteUpperShadow(ohlcv1) < shortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: short upper shadow
            //    (
            //        // 2nd far smaller than 1st, 3rd not longer than 2nd (advance blocked with the 2nd, 3rd must not carry on the advance)
            //        (RealBody(ohlcv2) < RealBody(ohlcv1) - farCriterion.AverageValue(ohlcvList, 3, ohlcv1) &&
            //         RealBody(ohlcv3) < RealBody(ohlcv2) - neaCriterion.AverageValue(ohlcvList, 2, ohlcv2)
            //        ) ||
            //        // 3rd far smaller than 2nd (advance blocked with the 3rd)
            //        (RealBody(ohlcv3) < RealBody(ohlcv2) - farCriterion.AverageValue(ohlcvList, 2, ohlcv2)
            //        ) ||
            //        // 3rd smaller than 2nd && 2nd smaller than 1st && (3rd or 2nd not short upper shadow) (advance blocked with progressively smaller real bodies and some upper shadows)
            //        (RealBody(ohlcv3) < RealBody(ohlcv2) && RealBody(ohlcv2) < RealBody(ohlcv1) &&
            //            (WhiteUpperShadow(ohlcv3) > shortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) ||
            //             WhiteUpperShadow(ohlcv2) > shortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2)
            //            )
            //        ) ||
            //        // 3rd smaller than 2nd && 3rd long upper shadow (advance blocked with 3rd candle's long upper shadow and smaller body)
            //        (RealBody(ohlcv3) < RealBody(ohlcv2) &&
            //         WhiteUpperShadow(ohlcv3) > longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3)
            //        )
            //    ))
            //    return -100;

            if (IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv2.Close && ohlcv2.Close > ohlcv1.Close && // consecutive higher closes
                ohlcv2.Open > ohlcv1.Open && ohlcv3.Open > ohlcv2.Open) // 2nd opens within 1st real body, 3rd opens within 2nd real body
            {
                double near2 = nearCriterion.AverageValue(ohlcvList, 2, ohlcv2);
                if (ohlcv3.Open <= ohlcv2.Close + near2) // 3rd opens within/near 2nd real body
                {
                    double realBody1 = RealBody(ohlcv1), realBody2 = RealBody(ohlcv2), realBody3 = RealBody(ohlcv3);
                    if (realBody1 > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                        WhiteUpperShadow(ohlcv1) < shortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: short upper shadow
                        (
                            // 2nd far smaller than 1st, 3rd not longer than 2nd (advance blocked with the 2nd, 3rd must not carry on the advance)
                            (realBody2 < realBody1 - farCriterion.AverageValue(ohlcvList, 3, ohlcv1) &&
                             realBody3 < realBody2 - near2
                            ) ||
                            // 3rd far smaller than 2nd (advance blocked with the 3rd)
                            (realBody3 < realBody2 - farCriterion.AverageValue(ohlcvList, 2, ohlcv2)
                            ) ||
                            // 3rd smaller than 2nd && 2nd smaller than 1st && (3rd or 2nd not short upper shadow) (advance blocked with progressively smaller real bodies and some upper shadows)
                            (realBody3 < realBody2 && realBody2 < realBody1 &&
                                (WhiteUpperShadow(ohlcv3) > shortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) ||
                                 WhiteUpperShadow(ohlcv2) > shortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2)
                                )
                            ) ||
                            // 3rd smaller than 2nd && 3rd long upper shadow (advance blocked with 3rd candle's long upper shadow and smaller body)
                            (realBody3 < realBody2 &&
                             WhiteUpperShadow(ohlcv3) > longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3)
                            )
                        ))
                        return -100;
                }
            }    
            return 0;
        }
    }
}
