﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the HikkakeModified pattern.
        /// </summary>
        public const int HikkakeModifiedCandlesticks = 4;

        /// <summary>
        /// The HikkakeModified pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HikkakeModified(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HikkakeModifiedCandlesticks;
            if (count < nearCriterion.AveragePeriod)
                return 0;

            return HikkakeModifiedInternal(ohlcvList[count], ohlcvList[++count], ohlcvList[++count], ohlcvList[++count], null, ohlcvList, 3);
        }

        /// <summary>
        /// The HikkakeModified pattern confirmation.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HikkakeModifiedConfirmation(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HikkakeModifiedCandlesticks - 1;
            if (count < nearCriterion.AveragePeriod)
                return 0;

            // One day ago.
            int index = count;
            Ohlcv ohlcv1 = ohlcvList[index], ohlcv2 = ohlcvList[++index], ohlcv3 = ohlcvList[++index], ohlcv4 = ohlcvList[++index], confirmation = ohlcvList[++index]; 
            int result = HikkakeModifiedInternal(ohlcv1, ohlcv2, ohlcv3, ohlcv4, confirmation, ohlcvList, 4);
            if (result != 0)
                return result;

            if (count > 0)
            {
                // Two days ago.
                ohlcv4 = ohlcvList[count - 1];
                result = HikkakeModifiedInternal(ohlcv4, ohlcv1, ohlcv2, ohlcv3, confirmation, ohlcvList, 5);
                if (result != 0)
                    return result;

                if (count > 1)
                {
                    // Three days ago.
                    ohlcv3 = ohlcvList[count - 2];
                    result = HikkakeModifiedInternal(ohlcv3, ohlcv4, ohlcv1, ohlcv2, confirmation, ohlcvList, 6);
                    if (result != 0)
                        return result;
                }
            }

            return 0;
        }

        private int HikkakeModifiedInternal(Ohlcv ohlcv1, Ohlcv ohlcv2, Ohlcv ohlcv3, Ohlcv ohlcv4, Ohlcv confirmation, List<Ohlcv> ohlcvList, int nearOffset)
        {
            // Must have:
            // - first candle,
            // - second candle: candle with range less than first candle and close near the bottom (near the top),
            // - third candle: lower high and higher low than 2nd,
            // - fourth candle: lower high and lower low (higher high and higher low) than 3rd.
            // Output is equal to 100 + the bullish hikkake result or -100 - the bearish hikkake result.
            // Confirmation could come in the next 3 days with a day that closes higher than the high (lower than the low) of the 3rd candle.
            // The confirmation output is equal to 100 + the bullish hikkake result or -100 - the bearish hikkake result.
            // If confirmation and a new hikkake come at the same bar, only the new hikkake is reported (the new hikkake overwrites the confirmation of the old hikkake).
            // The user should consider that modified hikkake is a reversal pattern, while hikkake could be both a reversal or a continuation pattern, so bullish (bearish) modified hikkake is significant when appearing in a downtrend (uptrend).

            if (ohlcv2.High < ohlcv1.High && ohlcv2.Low > ohlcv1.Low && // 2nd: has lower high and higher low than 1st
                ohlcv3.High < ohlcv2.High && ohlcv3.Low > ohlcv2.Low) // 3rd: has lower high and higher low than 2nd
            {
                if (ohlcv4.High < ohlcv3.High && ohlcv4.Low < ohlcv3.Low && // 4th: (bull) lower high and lower low
                    ohlcv2.Close <= ohlcv2.Low + nearCriterion.AverageValue(ohlcvList, nearOffset, ohlcv2)) // 2nd: (bull) close near the low
                {
                    if (null != confirmation)
                    {
                        if (confirmation.Close > ohlcv3.High) // confirmation close higher than the high of 3rd
                            return 100;
                        return 0;
                    }
                    return 50;
                }

                if (ohlcv4.High > ohlcv3.High && ohlcv4.Low > ohlcv3.Low && // 4th: (bear) higher high and higher low
                    ohlcv2.Close >= ohlcv2.High - nearCriterion.AverageValue(ohlcvList, nearOffset, ohlcv2)) // 2nd: (bear) close near the top
                {
                    if (null != confirmation)
                    {
                        if (confirmation.Close < ohlcv3.High) // confirmation close lower than the low of 3rd
                            return -100;
                        return 0;
                    }
                    return -50;
                }
            }

            return 0;
        }
    }
}
