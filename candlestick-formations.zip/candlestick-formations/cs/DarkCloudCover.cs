﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the DarkCloudCover pattern.
        /// </summary>
        public const int DarkCloudCoverCandlesticks = 2;

        /// <summary>
        /// Specifies the meaning of "moves well within" for an an abandoned baby pattern.
        /// The value must be in range [0, 3e+37], the default value is 0.5.
        /// </summary>
        public double DarkCloudCoverPenetrationFactor = 0.5;

        /// <summary>
        /// The DarkCloudCover pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int DarkCloudCover(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - DarkCloudCoverCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long white candle,
            // - second candle: black candle that opens above previous day high and closes within previous day real body; Greg Morris wants the close to be below the midpoint of the previous real body.
            // The the penetration of the first real body is specified with DarkCloudCoverPenetrationFactor.
            // Output is negative (-1 to -100): dark cloud cover is always bearish.
            // The user should consider that a dark cloud cover is significant when it appears in an uptrend, while this function does not consider it.

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                ohlcv2.Open > ohlcv1.High && // 2nd: open above 1st high
                ohlcv2.Close > ohlcv1.Open && // 2nd: close within 1st body
                ohlcv2.Close < ohlcv1.Close - WhiteRealBody(ohlcv1) * DarkCloudCoverPenetrationFactor && // 2nd: close within 1st body + Greg Morris
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1)) // 1st: long candle
                return -100;

            return 0;
        }
    }
}
