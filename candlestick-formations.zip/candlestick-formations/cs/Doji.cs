﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Doji pattern.
        /// </summary>
        public const int DojiCandlesticks = 1;

        /// <summary>
        /// Doji form when a security's open and close are virtually equal.
        /// The length of the upper and lower shadows can vary, and the resulting candlestick looks like, either, a cross, inverted cross, or plus sign.
        /// Doji convey a sense of indecision or tug-of-war between buyers and sellers.
        /// Prices move above and below the opening level during the session, but close at or near the opening level.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Doji(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - DojiCandlesticks;
            if (0 > count - dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv = ohlcvList[count];

            // Proceed with the calculation for the requested range.
            // Must have:
            // - open quite equal to close
            // Output is positive (1 to 100) but this does not mean it is bullish:
            // doji shows uncertainty and it is neither bullish nor bearish when considered alone.

            return (
                RealBody(ohlcv) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv) // Open quite equal to close.
                ) ? 100 : 0;
        }
    }
}
