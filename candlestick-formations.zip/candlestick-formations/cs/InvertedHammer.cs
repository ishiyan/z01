﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the InvertedHammer pattern.
        /// </summary>
        public const int InvertedHammerCandlesticks = 2;

        /// <summary>
        /// The InvertedHammer pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int InvertedHammer(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - InvertedHammerCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - small real body,
            // - long upper shadow,
            // - no, or very short, lower shadow,
            // - gap down.
            // Output is positive (1 to 100): inverted hammer is always bullish.
            // The user should consider that an inverted hammer is significant when it appears in a downtrend,
            // while this function does not consider the trend.

            if (RealBody(ohlcv2) < shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: small real body
                UpperShadow(ohlcv2) > longShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: long upper shadow
                LowerShadow(ohlcv2) > veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short lower shadow
                IsRealBodyGapDown(ohlcv1, ohlcv2)) // 2nd: gap down
                return 100;

            return 0;
        }
    }
}
