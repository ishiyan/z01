﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Engulfing pattern.
        /// </summary>
        public const int EngulfingCandlesticks = 2;

        /// <summary>
        /// Engulfing pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Engulfing(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - EngulfingCandlesticks;
            if (0 > count)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first: black (white) real body
            // - second: white (black) real body that engulfs the prior real body
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish;
            // the user should consider that an engulfing must appear in a downtrend if bullish or in an uptrend if bearish,
            // while this function does not consider it.

            // White engulfs black.
            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1)) // 2nd: engulfs the 1st's real body
                return 100; // Bullish.

            // Black engulfs white.
            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1)) // 2nd: engulfs the 1st's real body
                return -100; // Bearish.

            return 0;
        }

        /// <summary>
        /// Engulfing pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if a match was found.</returns>
        public bool EngulfingBullish(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - EngulfingCandlesticks;
            if (0 > count)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count++], ohlcv2 = ohlcvList[count];

            // Must have:
            // - first: black real body
            // - second: white real body that engulfs the prior real body
            // Output is positive;
            // the user should consider that an engulfing must appear in a downtrend,
            // while this function does not consider it.

            // White engulfs black.
            return (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1)); // 2nd: engulfs the 1st's real body
        }

        /// <summary>
        /// Engulfing pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if a match was found.</returns>
        public bool EngulfingBearish(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - EngulfingCandlesticks;
            if (0 > count)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count++], ohlcv2 = ohlcvList[count];

            // Must have:
            // - first: white real body
            // - second: black real body that engulfs the prior real body
            // Output is negative;
            // the user should consider that an engulfing must appear in an uptrend,
            // while this function does not consider it.

            // Black engulfs white.
            return (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsRealBodyEnclosesRealBody(ohlcv2, ohlcv1)); // 2nd: engulfs the 1st's real body
        }
    }
}
