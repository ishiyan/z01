﻿namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The entities of range that can be considered when to compare a part of a candlestick to other candlesticks.
    /// </summary>
    public enum RangeEntity
    {
        /// <summary>
        /// Identifies the length of the real body of a candlestick.
        /// </summary>
        RealBody,

        /// <summary>
        /// Identifies the length of the high - low of a candlestick.
        /// </summary>
        HighLow,

        /// <summary>
        /// Identifies the length of the shadows of a candlestick.
        /// </summary>
        Shadows
    }
}
