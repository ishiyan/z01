﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ThreeWhiteSoldiers pattern.
        /// </summary>
        public const int ThreeWhiteSoldiersCandlesticks = 3;

        /// <summary>
        /// The ThreeWhiteSoldiers pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ThreeWhiteSoldiers(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeWhiteSoldiersCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod ||
                count < farCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - three white candlesticks with consecutively higher closes,
            // - Greg Morris wants them to be long, Steve Nison doesn't; anyway they should not be short,
            // - each candle opens within or near the previous white real body,
            // - each candle must have no or very short upper shadow.
            // Output is positive (1 to 100): advancing 3 white soldiers is always bullish.
            // The user should consider that 3 white soldiers is significant when it appears in a downtrend, while this function does not consider it.

            if (IsWhite(ohlcv1) && // 1st: white
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv2.Close && ohlcv2.Close > ohlcv1.Close) // consecutive higher closes
            {
                if (UpperShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: very short upper shadow
                    UpperShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short upper shadow
                    UpperShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: very short upper shadow
                    ohlcv2.Open > ohlcv1.Open && ohlcv2.Open <= ohlcv1.Close + nearCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 2nd: opens within/near the 1st real body
                    ohlcv3.Open > ohlcv2.Open && ohlcv3.Open <= ohlcv2.Close + nearCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 3rd: opens within/near the 2nd real body
                    RealBody(ohlcv2) > RealBody(ohlcv1) - farCriterion.AverageValue(ohlcvList, 3, ohlcv1)) // 2nd: not far shorter than 1st
                {
                    double value = RealBody(ohlcv3);
                    if (value > RealBody(ohlcv2) - farCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 3rd: not far shorter than 2nd
                        value > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: not short real body
                    return 100;
                }
            }
            return 0;

            //return (
            //    IsWhite(ohlcv1) && // 1st: white
            //    IsWhite(ohlcv2) && // 2nd: white
            //    IsWhite(ohlcv3) && // 3rd: white
            //    UpperShadow(ohlcv1) < veryShortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: very short upper shadow
            //    UpperShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: very short upper shadow
            //    UpperShadow(ohlcv3) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv3) && // 3rd: very short upper shadow
            //    ohlcv3.Close > ohlcv2.Close && ohlcv2.Close > ohlcv1.Close && // consecutive higher closes
            //    ohlcv2.Open > ohlcv1.Open && ohlcv2.Open <= ohlcv1.Close + nearCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 2nd: opens within/near the 1st real body
            //    ohlcv3.Open > ohlcv2.Open && ohlcv3.Open <= ohlcv2.Close + nearCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 3rd: opens within/near the 2nd real body
            //    RealBody(ohlcv2) > RealBody(ohlcv1) - farCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 2nd: not far shorter than 1st
            //    RealBody(ohlcv3) > RealBody(ohlcv2) - farCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 3rd: not far shorter than 2nd
            //    RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: not short real body
            //    ) ? 100 : 0;
        }
    }
}
