﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the SeparatingLines pattern.
        /// </summary>
        public const int SeparatingLinesCandlesticks = 2;

        /// <summary>
        /// The SeparatingLines pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int SeparatingLines(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - SeparatingLinesCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: black (white) candle,
            // - second candle: bullish (bearish) belt hold with the same open as the prior candle.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that separating lines patern is significant when coming in a trend
            // and the belt hold has the same direction of the trend, while this function does not consider it.

            if (((IsWhite(ohlcv1) && IsBlack(ohlcv2)) || // 1st: white, 2nd: black
                (IsBlack(ohlcv1) && IsWhite(ohlcv2))) && // 1st: black, 2nd: white
                RealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: belt hold: long body
            {
                double range = equalCriterion.AverageValue(ohlcvList, 1, ohlcv2);
                if (ohlcv2.Open <= (ohlcv1.Open + range) && ohlcv2.Open >= (ohlcv1.Open - range)) // same open
                {
                    range = veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2);
                    if (IsWhite(ohlcv2) && WhiteLowerShadow(ohlcv2) < range) // with no lower shadow if bullish
                        return 100;
                    if (IsBlack(ohlcv2) && BlackUpperShadow(ohlcv2) < range) // with no upper shadow if bearish
                        return -100;
                }
            }

            return 0;
        }
    }
}
