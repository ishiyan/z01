﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the HangingMan pattern.
        /// </summary>
        public const int HangingManCandlesticks = 2;

        /// <summary>
        /// The HangingMan pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HangingMan(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HangingManCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - small real body,
            // - long lower shadow,
            // - no, or very short, upper shadow,
            // - body above or near the highs of the previous candle.
            // Output is negative (-1 to -100): hanging man is always bearish.
            // The user should consider that a hanging man must appear in an uptrend,
            // while this function does not consider it.

            if (RealBody(ohlcv2) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2) && // small real body
                LowerShadow(ohlcv2) > longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2) && // long lower shadow
                UpperShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2) && // no, or very short, upper shadow
                Math.Min(ohlcv2.Open, ohlcv1.Close) >= ohlcv2.High - nearCriterion.AverageValue(ohlcvList, 2, ohlcv1)) // real body near the prior candle's highs
                return 100;

            return 0;
        }
    }
}
