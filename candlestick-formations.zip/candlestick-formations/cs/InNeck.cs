﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the InNeck pattern.
        /// </summary>
        public const int InNeckCandlesticks = 2;

        /// <summary>
        /// The InNeck pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int InNeck(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - InNeckCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: white candle with open below previous day low and close slightly into previous day body.
            // Output is negative (-1 to -100): in-neck is always bearish.
            // The user should consider that a in-neck is significant when it appears in an downtrend,
            // while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                ohlcv2.Open < ohlcv1.Low && // 2nd: open below prior low
                ohlcv2.Close >= ohlcv1.Close && // 2nd: close slightly into prior body
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                ohlcv2.Close <= ohlcv1.Close + equalCriterion.AverageValue(ohlcvList, 2, ohlcv1)) // 2nd: close slightly into prior body
                return -100;

            return 0;
        }
    }
}
