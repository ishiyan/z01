﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the LongLeggedDoji pattern.
        /// </summary>
        public const int LongLeggedDojiCandlesticks = 1;

        /// <summary>
        /// The LongLeggedDoji pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int LongLeggedDoji(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - LongLeggedDojiCandlesticks;
            if (count < longShadowCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count];

            // Must have:
            // - doji body,
            // - one or two long shadows.
            // Output is always positive (1 to 100) but this does not mean it is bullish: long legged doji shows uncertainty.

            if (RealBody(ohlcv1) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // doji
            {
                double longShadow = longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1);
                if (LowerShadow(ohlcv1) > longShadow || UpperShadow(ohlcv1) > longShadow) // one or two long shadows
                    return 100;
            }

            return 0;
        }
    }
}
