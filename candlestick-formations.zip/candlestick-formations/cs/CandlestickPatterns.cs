﻿using System;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        #region Default criteria
        /// <summary>
        /// Real body is long when it is longer than the average of the real body of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultLongRealBodyCriterion = new Criterion(RangeEntity.RealBody, 10, 1d);

        /// <summary>
        /// Real body is very long when it is longer than 3 times the average of the real body of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultVeryLongRealBodyCriterion = new Criterion(RangeEntity.RealBody, 10, 3d);

        /// <summary>
        /// Real body is short when it is shorter than the average of the real body of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultShortRealBodyCriterion = new Criterion(RangeEntity.RealBody, 10, 1d);

        /// <summary>
        /// Real body is like doji when it is shorter than 10% the average of the high-low range of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultDojiRealBodyCriterion = new Criterion(RangeEntity.HighLow, 10, 0.1);

        /// <summary>
        /// Shadow is long when it is longer than the real body.
        /// </summary>
        public static readonly Criterion DefaultLongShadowCriterion = new Criterion(RangeEntity.RealBody, 0, 1d);

        /// <summary>
        /// Shadow is very long when it is longer than 2 times the real body.
        /// </summary>
        public static readonly Criterion DefaultVeryLongShadowCriterion = new Criterion(RangeEntity.RealBody, 0, 2d);

        /// <summary>
        /// Shadow is short when it is shorter than half the average of the sum of shadows of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultShortShadowCriterion = new Criterion(RangeEntity.Shadows, 10, 0.5); // Was 1.0: error in ta-lib?????

        /// <summary>
        /// Shadow is short when it is shorter than 10% the average of the high-low range of the 10 previous candlesticks.
        /// </summary>
        public static readonly Criterion DefaultVeryShortShadowCriterion = new Criterion(RangeEntity.HighLow, 10, 0.1);

        /// <summary>
        /// When measuring distance between parts of candles or width of gaps 'near' means &lt;= 20% of the average of the high-low range of the 5 previous candlessticks.
        /// </summary>
        public static readonly Criterion DefaultNearCriterion = new Criterion(RangeEntity.HighLow, 5, 0.2);

        /// <summary>
        /// When measuring distance between parts of candles or width of gaps 'far' means &gt;= 60% of the average of the high-low range of the 5 previous candlessticks.
        /// </summary>
        public static readonly Criterion DefaultFarCriterion = new Criterion(RangeEntity.HighLow, 5, 0.6);

        /// <summary>
        /// When measuring distance between parts of candles or width of gaps 'equal' means &lt;= 5% of the average of the high-low range of the 5 previous candlessticks.
        /// </summary>
        public static readonly Criterion DefaultEqualCriterion = new Criterion(RangeEntity.HighLow, 5, 0.05);
        #endregion

        #region Criteria
        #region Long real body
        private Criterion longRealBodyCriterion = new Criterion(DefaultLongRealBodyCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the real body is long.
        /// </summary>
        public Criterion LongRealBodyCriterion
        {
            get { return longRealBodyCriterion; }
            set { longRealBodyCriterion = value; }
        }
        #endregion

        #region Very long real body
        private Criterion veryLongRealBodyCriterion = new Criterion(DefaultVeryLongRealBodyCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the real body is very long.
        /// </summary>
        public Criterion VeryLongRealBodyCriterion
        {
            get { return veryLongRealBodyCriterion; }
            set { veryLongRealBodyCriterion = value; }
        }
        #endregion

        #region Short real body
        private Criterion shortRealBodyCriterion = new Criterion(DefaultShortRealBodyCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the real body is short.
        /// </summary>
        public Criterion ShortRealBodyCriterion
        {
            get { return shortRealBodyCriterion; }
            set { shortRealBodyCriterion = value; }
        }
        #endregion

        #region Doji real body
        private Criterion dojiRealBodyCriterion = new Criterion(DefaultDojiRealBodyCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the real body is like doji's body.
        /// </summary>
        public Criterion DojiRealBodyCriterion
        {
            get { return dojiRealBodyCriterion; }
            set { dojiRealBodyCriterion = value; }
        }
        #endregion

        #region Long shadow
        private Criterion longShadowCriterion = new Criterion(DefaultLongShadowCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the shadow is long.
        /// </summary>
        public Criterion LongShadowCriterion
        {
            get { return longShadowCriterion; }
            set { longShadowCriterion = value; }
        }
        #endregion

        #region Very long shadow
        private Criterion veryLongShadowCriterion = new Criterion(DefaultVeryLongShadowCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the shadow is very long.
        /// </summary>
        public Criterion VeryLongShadowCriterion
        {
            get { return veryLongShadowCriterion; }
            set { veryLongShadowCriterion = value; }
        }
        #endregion

        #region Short shadow
        private Criterion shortShadowCriterion = new Criterion(DefaultShortShadowCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the shadow is short.
        /// </summary>
        public Criterion ShortShadowCriterion
        {
            get { return shortShadowCriterion; }
            set { shortShadowCriterion = value; }
        }
        #endregion

        #region Very short shadow
        private Criterion veryShortShadowCriterion = new Criterion(DefaultVeryShortShadowCriterion);

        /// <summary>
        /// Identifies a criterion to determine if the shadow is very short.
        /// </summary>
        public Criterion VeryShortShadowCriterion
        {
            get { return veryShortShadowCriterion; }
            set { veryShortShadowCriterion = value; }
        }
        #endregion

        #region Near
        private Criterion nearCriterion = new Criterion(DefaultNearCriterion);

        /// <summary>
        /// Identifies a criterion to determine if candlesticks are near.
        /// </summary>
        public Criterion NearCriterion
        {
            get { return nearCriterion; }
            set { nearCriterion = value; }
        }
        #endregion

        #region Far
        private Criterion farCriterion = new Criterion(DefaultFarCriterion);

        /// <summary>
        /// Identifies a criterion to determine if candlesticks are far.
        /// </summary>
        public Criterion FarCriterion
        {
            get { return farCriterion; }
            set { farCriterion = value; }
        }
        #endregion

        #region Equal
        private Criterion equalCriterion = new Criterion(DefaultEqualCriterion);

        /// <summary>
        /// Identifies a criterion to determine if candlesticks are equal.
        /// </summary>
        public Criterion EqualCriterion
        {
            get { return equalCriterion; }
            set { equalCriterion = value; }
        }
        #endregion
        #endregion

        #region Candlestick primitives
        #region IsWhite
        /// <summary>
        /// Determines if the candlestick is white.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the candlestick is white.</returns>
        private static bool IsWhite(Ohlcv ohlcv)
        {
            return ohlcv.Close >= ohlcv.Open;
        }
        #endregion

        #region WhiteRealBody
        /// <summary>
        /// Calculates the length of the real body of a white candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the real body.</returns>
        private static double WhiteRealBody(Ohlcv ohlcv)
        {
            return ohlcv.Close - ohlcv.Open;
        }
        #endregion

        #region IsBlack
        /// <summary>
        /// Determines if the candlestick is black.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the candlestick is black.</returns>
        private static bool IsBlack(Ohlcv ohlcv)
        {
            return ohlcv.Close < ohlcv.Open;
        }
        #endregion

        #region BlackRealBody
        /// <summary>
        /// Calculates the length of the real body of a black candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the real body.</returns>
        private static double BlackRealBody(Ohlcv ohlcv)
        {
            return ohlcv.Open - ohlcv.Close;
        }
        #endregion

        #region RealBody
        /// <summary>
        /// Calculates the length of the real body of a candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the real body.</returns>
        private static double RealBody(Ohlcv ohlcv)
        {
            return (ohlcv.IsRising ? (ohlcv.Close - ohlcv.Open) : (ohlcv.Open - ohlcv.Close));
        }
        #endregion

        #region IsRealBodyGapUp
        /// <summary>
        /// Determines if two candlesticks have a real body gap up: the max(open, close) value of the first candlestick is less than the min(open, close) value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if there is a real body gap up.</returns>
        private static bool IsRealBodyGapUp(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            return // max(ohlcv1) < min(ohlcv2)
                (ohlcv1.Close > ohlcv1.Open ? ohlcv1.Close : ohlcv1.Open) <
                (ohlcv2.Close < ohlcv2.Open ? ohlcv2.Close : ohlcv2.Open);
        }
        #endregion

        #region IsRealBodyGapDown
        /// <summary>
        /// Determines if two candlesticks have a real body gap down: the min(open, close) value of the first candlestick is greater than the max(open, close) value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if there is a real body gap up.</returns>
        private static bool IsRealBodyGapDown(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            return // min(ohlcv1) > max(ohlcv2)
                (ohlcv1.Close < ohlcv1.Open ? ohlcv1.Close : ohlcv1.Open) >
                (ohlcv2.Close > ohlcv2.Open ? ohlcv2.Close : ohlcv2.Open);
        }
        #endregion

        #region IsHighLowGapUp
        /// <summary>
        /// Determines if two candlesticks have a gap up: the high value of the first candlestick is less than the low value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if there is a gap up.</returns>
        private static bool IsHighLowGapUp(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            return ohlcv1.High < ohlcv2.Low;
        }
        #endregion

        #region IsHighLowGapDown
        /// <summary>
        /// Determines if two candlesticks have a gap down: the low value of the first candlestick is greater than the high value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if there is a gap down.</returns>
        private static bool IsHighLowGapDown(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            return ohlcv1.Low > ohlcv2.High;
        }
        #endregion

        #region IsRealBodyEnclosesRealBody
        /// <summary>
        /// Determines if the real body of the first candlestick completely encloses the real body of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the real body of the first candlestick encloses the real body of the second candlestick.</returns>
        private static bool IsRealBodyEnclosesRealBody(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            double min1, max1;
            if (ohlcv1.Close > ohlcv1.Open)
            {
                min1 = ohlcv1.Open;
                max1 = ohlcv1.Close;
            }
            else
            {
                min1 = ohlcv1.Close;
                max1 = ohlcv1.Open;
            }
            double min2, max2;
            if (ohlcv2.Close > ohlcv2.Open)
            {
                min2 = ohlcv2.Open;
                max2 = ohlcv2.Close;
            }
            else
            {
                min2 = ohlcv2.Close;
                max2 = ohlcv2.Open;
            }
            return max1 > max2 && min1 < min2;
        }
        #endregion

        #region IsRealBodyEnclosesOpen
        /// <summary>
        /// Determines if the real body of the first candlestick completely encloses the open value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the real body of the first candlestick encloses the open value of the second candlestick.</returns>
        private static bool IsRealBodyEnclosesOpen(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            double open2 = ohlcv2.Open;
            double open1 = ohlcv1.Open, close1 = ohlcv1.Close;
            return open1 > close1 ? open2 < open1 && open2 > close1 : open2 > open1 && open2 < close1;
        }
        #endregion

        #region IsRealBodyEnclosesClose
        /// <summary>
        /// Determines if the real body of the first candlestick completely encloses the close value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the real body of the first candlestick encloses the close value of the second candlestick.</returns>
        private static bool IsRealBodyEnclosesClose(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            double close2 = ohlcv2.Close;
            double open1 = ohlcv1.Open, close1 = ohlcv1.Close;
            return open1 > close1 ? close2 < open1 && close2 > close1 : close2 > open1 && close2 < close1;
        }
        #endregion

        #region WhiteLowerShadow
        /// <summary>
        /// Calculates the length of the lower shadow of a white candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the lower shadow.</returns>
        private static double WhiteLowerShadow(Ohlcv ohlcv)
        {
            return ohlcv.Open - ohlcv.Low;
        }
        #endregion

        #region BlackLowerShadow
        /// <summary>
        /// Calculates the length of the lower shadow of a black candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the lower shadow.</returns>
        private static double BlackLowerShadow(Ohlcv ohlcv)
        {
            return ohlcv.Close - ohlcv.Low;
        }
        #endregion

        #region LowerShadow
        /// <summary>
        /// Calculates the length of the lower shadow of a candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the lower shadow.</returns>
        private static double LowerShadow(Ohlcv ohlcv)
        {
            return (ohlcv.Close >= ohlcv.Open ? ohlcv.Open : ohlcv.Close) - ohlcv.Low;
        }
        #endregion

        #region WhiteUpperShadow
        /// <summary>
        /// Calculates the length of the upper shadow of a white candlestick.
        /// </summary>
        /// <param name="ohlcv">A <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the upper shadow.</returns>
        private static double WhiteUpperShadow(Ohlcv ohlcv)
        {
            return ohlcv.High - ohlcv.Close;
        }
        #endregion

        #region BlackUpperShadow
        /// <summary>
        /// Calculates the length of the upper shadow of a black candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the upper shadow.</returns>
        private static double BlackUpperShadow(Ohlcv ohlcv)
        {
            return ohlcv.High - ohlcv.Open;
        }
        #endregion

        #region UpperShadow
        /// <summary>
        /// Calculates the length of the upper shadow of a candlestick.
        /// </summary>
        /// <param name="ohlcv">An <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>The length of the upper shadow.</returns>
        private static double UpperShadow(Ohlcv ohlcv)
        {
            return ohlcv.High - (ohlcv.Close >= ohlcv.Open ? ohlcv.Close : ohlcv.Open);
        }
        #endregion

        #region IsHighExceedsClose
        /// <summary>
        /// Determines if the high value of the first candlestick is greater than the close value of the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <returns>True if the high value of the first candlestick is greater than the close value of the second candlestick.</returns>
        private static bool IsHighExceedsClose(Ohlcv ohlcv1, Ohlcv ohlcv2)
        {
            return ohlcv1.High > ohlcv2.Close;
        }
        #endregion

        #region IsOpensWithin
        /// <summary>
        /// Determines if the first candlestick opens within the second candlestick.
        /// </summary>
        /// <param name="ohlcv1">The first <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="ohlcv2">The second <see cref="Ohlcv">ohlcv bar</see>.</param>
        /// <param name="tolerance">The tolerance.</param>
        /// <returns>True if the high value of the first candlestick is greater than the close value of the second candlestick.</returns>
        private static bool IsOpensWithin(Ohlcv ohlcv1, Ohlcv ohlcv2, double tolerance = 0.0)
        {
            double open1 = ohlcv1.Open, open2 = ohlcv2.Open, close2 = ohlcv2.Close;
            return (open1 >= Math.Min(open2, close2) - tolerance) &&
                   (open1 <= Math.Max(open2, close2) + tolerance);
        }
        #endregion

        #endregion
    }
}
