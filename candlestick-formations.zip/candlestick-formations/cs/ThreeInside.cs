﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ThreeInside pattern.
        /// </summary>
        public const int ThreeInsideCandlesticks = 3;

        /// <summary>
        /// Three Inside Up/Down.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ThreeInside(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeInsideCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long white (black) real body,
            // - second candle: short real body totally engulfed by the first,
            // - third candle: black (white) candle that closes lower (higher) than the first candle's open.
            // The output is positive (1 to 100) for the three inside up or negative (-1 to -100) for the three inside down;
            // the user should consider that a three inside up is significant when it appears in a downtrend and a three inside
            // down is significant when it appears in an uptrend, while this function does not consider the trend.

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 3rd: black
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long white real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short real body
                IsRealBodyEnclosesRealBody(ohlcv1, ohlcv2) && // 2nd: real body totally engulfed by the 1st's real body
                ohlcv3.Close < ohlcv1.Open) // 3rd: closes lower than the 1st's open
                return -100; // down

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv3) && // 3rd: white
                BlackRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long black real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short real body
                IsRealBodyEnclosesRealBody(ohlcv1, ohlcv2) && // 2nd: real body totally engulfed by the 1st's real body
                ohlcv3.Close > ohlcv1.Open) // 3rd: closes higher than the 1st's open
                return 100; // up

            return 0;
        }

        /// <summary>
        /// Three Inside Up.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if there is a match.</returns>
        public bool ThreeInsideUp(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeInsideCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long black real body,
            // - second candle: short real body totally engulfed by the first,
            // - third candle: white candle that closes higher than the first candle's open.
            // The output is positive for the three inside up; 
            // the user should consider that a three inside up is significant when it appears in a downtrend,
            // while this function does not consider the trend

            return (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv3) && // 3rd: white
                BlackRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long black real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short real body
                IsRealBodyEnclosesRealBody(ohlcv1, ohlcv2) && // 2nd: real body totally engulfed by the 1st's real body
                ohlcv3.Close > ohlcv1.Open); // 3rd: closes higher than the 1st's open
        }

        /// <summary>
        /// Three Inside Down.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A boolean indicating if there is a match.</returns>
        public bool ThreeInsideDown(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ThreeInsideCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return false;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long white real body,
            // - second candle: short real body totally engulfed by the first,
            // - third candle: black candle that closes lower than the first candle's open.
            // The output is negative for the three inside down; 
            // the user should consider that a three inside
            // down is significant when it appears in an uptrend, while this function does not consider the trend

            return (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 3rd: black
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long white real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short real body
                IsRealBodyEnclosesRealBody(ohlcv1, ohlcv2) && // 2nd: real body totally engulfed by the 1st's real body
                ohlcv3.Close < ohlcv1.Open); // 3rd: closes lower than the 1st's open
        }
    }
}
