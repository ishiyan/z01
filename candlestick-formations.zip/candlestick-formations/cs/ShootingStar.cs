﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ShootingStar pattern.
        /// </summary>
        public const int ShootingStarCandlesticks = 2;

        /// <summary>
        /// The ShootingStar pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ShootingStar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ShootingStarCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < longShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - small real body,
            // - long upper shadow,
            // - no, or very short, lower shadow,
            // - gap up from prior real body.
            // Output is negative (-1 to -100): shooting star is always bearish.
            // The user should consider that a shooting star is significant when it appears in an uptrend,
            // while this function does not consider the trend.

            if (IsRealBodyGapUp(ohlcv1, ohlcv2) && // 2nd: gap up from prior real body
                RealBody(ohlcv2) < shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2) && // 2nd: small real body
                UpperShadow(ohlcv2) > longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2) && // 2nd: long upper shadow
                LowerShadow(ohlcv2) < veryShortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: very short lower shadow
                return -100;

            return 0;
        }
    }
}
