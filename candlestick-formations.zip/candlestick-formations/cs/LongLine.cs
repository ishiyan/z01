using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the LongLine pattern.
        /// </summary>
        public const int LongLineCandlesticks = 1;

        /// <summary>
        /// The LongLine pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int LongLine(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - LongLineCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv = ohlcvList[count];

            // Must have:
            // - long real body,
            // - short upper and lower shadow.
            // Output is positive (1 to 100) when white (bullish), negative (-1 to -100) when black (bearish).

            if (RealBody(ohlcv) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv)) // long real body
            {
                double value = shortShadowCriterion.AverageValue(ohlcvList, 1, ohlcv);
                if (IsWhite(ohlcv) && UpperShadow(ohlcv) < value) // white and short upper shadow
                    return 100;

                if (/*IsBlack(ohlcv) &&*/ LowerShadow(ohlcv) < value) // black and short lower shadow
                    return -100;
            }

            return 0;
        }
    }
}
