﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the OnNeck pattern.
        /// </summary>
        public const int OnNeckCandlesticks = 2;

        /// <summary>
        /// The OnNeck pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int OnNeck(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - OnNeckCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: white candle with open below previous day low and close equal to previous day low.
            // Output is negative (-1 to -100): on-neck is always bearish.
            // The user should consider that a on-neck is significant when it appears in an downtrend,
            // while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                ohlcv2.Open < ohlcv1.Low && // 2nd: open below prior low
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1)) // 1st: long real body
            {
                double equal = equalCriterion.AverageValue(ohlcvList, 2, ohlcv1);
                if (ohlcv2.Close <= ohlcv1.Low + equal &&  ohlcv2.Close >= ohlcv1.Low - equal) // 2nd: close equal to prior low
                    return -100;
            }

            return 0;
        }
    }
}
