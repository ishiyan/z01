﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the ConcealingBabySwallow pattern.
        /// </summary>
        public const int ConcealingBabySwallowCandlesticks = 4;

        /// <summary>
        /// The ConcealingBabySwallow pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int ConcealingBabySwallow(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - ConcealingBabySwallowCandlesticks;
            if (count < veryShortShadowCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count];

            // Must have:
            // - first candle: black marubozu (very short shadows),
            // - second candle: black marubozu (very short shadows),
            // - third candle: black candle that opens gapping down but has an upper shadow that extends into the prior body,
            // - fourth candle: black candle that completely engulfs the third candle, including the shadows.
            // Output is positive (1 to 100): concealing baby swallow is always bullish.
            // The user should consider that a concealing baby swallow is significant when it appears in a downtrend, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                IsBlack(ohlcv4)) // 4th: black
            {
                double veryShort = veryShortShadowCriterion.AverageValue(ohlcvList, 4, ohlcv1);
                if (BlackLowerShadow(ohlcv1) < veryShort && BlackUpperShadow(ohlcv1) < veryShort) // 1st: marubozu
                {
                    veryShort = veryShortShadowCriterion.AverageValue(ohlcvList, 3, ohlcv2);
                    if (BlackLowerShadow(ohlcv2) < veryShort && BlackUpperShadow(ohlcv2) < veryShort && // 2nd: marubozu
                        IsRealBodyGapDown(ohlcv2, ohlcv3)) // 3rd: opens gapping down
                    {
                        veryShort = veryShortShadowCriterion.AverageValue(ohlcvList, 2, ohlcv3);
                        if (BlackUpperShadow(ohlcv3) > veryShort && ohlcv3.High > ohlcv2.Close && // 3rd: has an upper shadow that extends into the prior body
                            ohlcv4.High > ohlcv3.High && ohlcv4.Low < ohlcv3.Low) // 4th: engulfs the 3rd including the shadows
                            return 100;
                    }
                }
            }

            return 0;
        }
    }
}
