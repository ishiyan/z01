﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the RickshawMan pattern.
        /// </summary>
        public const int RickshawManCandlesticks = 1;

        /// <summary>
        /// The RickshawMan pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int RickshawMan(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - RickshawManCandlesticks;
            if (count < longShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count];

            // Must have:
            // - doji body,
            // - two long shadows,
            // - body near the midpoint of the high-low range.
            // Output is always positive (1 to 100) but this does not mean it is bullish: rickshaw man shows uncertainty.

            if (RealBody(ohlcv1) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv1)) // doji
            {
                double longShadow = longShadowCriterion.AverageValue(ohlcvList, 1, ohlcv1);
                if (LowerShadow(ohlcv1) > longShadow && UpperShadow(ohlcv1) > longShadow) // two long shadows
                {
                    double near = nearCriterion.AverageValue(ohlcvList, 1, ohlcv1);
                    double mid = ohlcv1.High / 2 + ohlcv1.Low / 2;
                    if (Math.Min(ohlcv1.Open, ohlcv1.Close) <= mid + near &&
                        Math.Max(ohlcv1.Open, ohlcv1.Close) >= mid - near)
                        return 100;
                }
            }

            return 0;
        }
    }
}
