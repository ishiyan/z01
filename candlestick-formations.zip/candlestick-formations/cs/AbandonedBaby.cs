﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the AbandonedBaby pattern.
        /// </summary>
        public const int AbandonedBabyCandlesticks = 3;

        /// <summary>
        /// Specifies the meaning of "moves well within" for an abandoned baby pattern.
        /// The value must be in range [0, 3e+37], the default value is 0.3.
        /// </summary>
        public double AbandonedBabyPenetrationFactor = 0.3;

        /// <summary>
        /// The AbandonedBaby pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int AbandonedBaby(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - AbandonedBabyCandlesticks;
            if (count < shortRealBodyCriterion.AveragePeriod ||
                count < longRealBodyCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod ||
                count < veryShortShadowCriterion.AveragePeriod ||
                count < nearCriterion.AveragePeriod ||
                count < farCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long white (black) real body,
            // - second candle: doji,
            // - third candle: black (white) real body that moves well within the first candle's real body,
            // - upside (downside) gap between the first candle and the doji (the shadows of the two candles don't touch),
            // - downside (upside) gap between the doji and the third candle (the shadows of the two candles don't touch).
            // The meaning of "moves well within" is specified with optInPenetration and "moves" should mean the real body should
            // not be short ("short" is specified with shortRealBodyCriterion) - Greg Morris wants it to be long, someone else want
            // it to be relatively long.
            // Output is positive (1 to 100) when it's an abandoned baby bottom or negative (-1 to -100) when it's an abandoned baby top.
            // The user should consider that an abandoned baby is significant when it appears in an uptrend or downtrend, while this function does not consider it.

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv3.Close < ohlcv1.Close - RealBody(ohlcv1) * AbandonedBabyPenetrationFactor && // 3rd: closes well within first candle's real body
                IsHighLowGapUp(ohlcv1, ohlcv2) && // upside gap between 1st and 2nd
                IsHighLowGapDown(ohlcv2, ohlcv3) && // downside gap between 2nd and 3rd
                RealBody(ohlcv1) < longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: doji
                RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: real body that moves well within the first candle's real body
                return -100;

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv1.Close - RealBody(ohlcv1) * AbandonedBabyPenetrationFactor && // 3rd: closes well within first candle's real body
                IsHighLowGapDown(ohlcv1, ohlcv2) && // downside gap between 1st and 2nd
                IsHighLowGapUp(ohlcv2, ohlcv3) && // upside gap between 2nd and 3rd
                RealBody(ohlcv1) < longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: doji
                RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: real body that moves well within the first candle's real body
                return 100;

            return 0;
        }
    }
}
