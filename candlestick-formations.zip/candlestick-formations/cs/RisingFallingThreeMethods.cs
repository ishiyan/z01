﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the RisingFallingThreeMethods pattern.
        /// </summary>
        public const int RisingFallingThreeMethodsCandlesticks = 5;

        /// <summary>
        /// The RisingFallingThreeMethods pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int RisingFallingThreeMethods(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - RisingFallingThreeMethodsCandlesticks;
            if (0 > count - longRealBodyCriterion.AveragePeriod ||
                0 > count - shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count], ohlcv4 = ohlcvList[++count], ohlcv5 = ohlcvList[++count];

            // Must have:
            // - first candle: long white (black) candlestick;
            // - then: group of falling (rising) small real body candlesticks (commonly black (white)) that hold within
            // the prior long candle's range: ideally they should be three but two or more than three are ok too;
            // - final candle: long white (black) candle that opens above (below) the previous small candle's close
            // and closes above (below) the first long candle's close.
            // The output is positive (1 to 100) or negative (-1 to -100).

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv2) && // 2nd: black
                IsBlack(ohlcv3) && // 3rd: black
                IsBlack(ohlcv4) && // 4th: black
                IsWhite(ohlcv5) && // 5th: white
                ohlcv2.Close < ohlcv1.High && ohlcv2.Open > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv3.Close < ohlcv1.High && ohlcv3.Open > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv4.Close < ohlcv1.High && ohlcv4.Open > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv3.Close < ohlcv2.Close && ohlcv4.Close < ohlcv3.Close && // 2nd to 4th are falling
                ohlcv5.Open > ohlcv4.Close && // 5th opens above the prior close            
                ohlcv5.Close > ohlcv1.Close && // 5th closes above the 1st close
                WhiteRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1) && // 1st: long real body
                BlackRealBody(ohlcv2) > shortRealBodyCriterion.AverageValue(ohlcvList, 4, ohlcv2) &&  // 2nd: short real body
                BlackRealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv3) &&  // 3rd: short real body
                BlackRealBody(ohlcv4) > shortRealBodyCriterion.AverageValue(ohlcvList, 4, ohlcv4) &&  // 4th: short real body
                WhiteRealBody(ohlcv5) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv5)) // 5th: long real body
                return 100;

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsWhite(ohlcv3) && // 3rd: white
                IsWhite(ohlcv4) && // 4th: white
                IsBlack(ohlcv5) && // 5th: black
                ohlcv2.Open < ohlcv1.High && ohlcv2.Close > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv3.Open < ohlcv1.High && ohlcv3.Close > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv4.Open < ohlcv1.High && ohlcv4.Close > ohlcv1.Low && // 2nd within 1st: a part of the real body must be within 1st range
                ohlcv3.Close > ohlcv2.Close && ohlcv4.Close > ohlcv3.Close && // 2nd to 4th are rising
                ohlcv5.Open < ohlcv4.Close && // 5th opens below the prior close
                ohlcv5.Close < ohlcv1.Close && // 5th closes below the 1st close
                BlackRealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 5, ohlcv1) && // 1st: long real body
                WhiteRealBody(ohlcv2) > shortRealBodyCriterion.AverageValue(ohlcvList, 4, ohlcv2) &&  // 2nd: short real body
                WhiteRealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv3) &&  // 3rd: short real body
                WhiteRealBody(ohlcv4) > shortRealBodyCriterion.AverageValue(ohlcvList, 4, ohlcv4) &&  // 4th: short real body
                BlackRealBody(ohlcv5) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv5)) // 5th: long real body
                return -100;

            return 0;
        }
    }
}
