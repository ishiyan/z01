﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the DojiStar pattern.
        /// </summary>
        public const int DojiStarCandlesticks = 2;

        /// <summary>
        /// Doji Star.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int DojiStar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - DojiStarCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long real body,
            // - second candle: star (open gapping up in an uptrend or down in a downtrend) with a doji.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish; 
            // it's defined bullish when the long candle is white and the star gaps up, bearish when the long candle 
            // is black and the star gaps down; the user should consider that a doji star is bullish when it appears 
            // in an uptrend and it's bearish when it appears in a downtrend, so to determine the bullishness or 
            // bearishness of the pattern the trend must be analyzed.

            if (IsWhite(ohlcv1) && // 1st: white
                IsRealBodyGapUp(ohlcv1, ohlcv2)) // 2nd: gapping up
                return (
                    RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                    RealBody(ohlcv2) > dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2) // 2nd: doji
                    ) ? 100 : 0;

            if (IsBlack(ohlcv1) && // 1st: black
                IsRealBodyGapDown(ohlcv1, ohlcv2)) // 2nd: gapping down
                return (
                    RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                    RealBody(ohlcv2) > dojiRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2) // 2nd: doji
                    ) ? -100 : 0;

            return 0;
        }
    }
}
