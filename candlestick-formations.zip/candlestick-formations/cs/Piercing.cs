﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the Piercing pattern.
        /// </summary>
        public const int PiercingCandlesticks = 2;

        /// <summary>
        /// The Piercing pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int Piercing(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - PiercingCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: long white candle with open below previous day low and close at least at 50% of previous day real body.
            // Output is positive (1 to 100): a piercing pattern is always bullish.
            // The user should consider that a piercing is significant when it appears in an downtrend,
            // while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                ohlcv2.Open < ohlcv1.Low && // 2nd: open below prior low
                ohlcv2.Close < ohlcv1.Open && // 2nd: closes within prior body
                ohlcv2.Close > ohlcv1.Close + RealBody(ohlcv1) * 0.5 && // 2nd: closes above midpoint
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) > longRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: long real body
                    return 100;

            return 0;
        }
    }
}
