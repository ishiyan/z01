﻿using System;
using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the TasukiGap pattern.
        /// </summary>
        public const int TasukiGapCandlesticks = 3;

        /// <summary>
        /// The TasukiGap pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int TasukiGap(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - TasukiGapCandlesticks;
            if (count < nearCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - upside (downside) gap,
            // - first candle after the window: white (black) candlestick,
            // - second candle: black (white) candlestick that opens within the previous real body and closes under (above) the previous real body inside the gap,
            // - the size of two real bodies should be near the same.
            // Output is positive (1 to 100) when bullish or negative (-1 to -100) when bearish.
            // The user should consider that a tasuki gap is significant when it appears in a trend,
            // while this function does not consider the trend.

            if (IsWhite(ohlcv2) && // 2nd: white (first candle after the gap)
                IsBlack(ohlcv3) && // 3rd: black (second candle after the gap)
                IsRealBodyGapUp(ohlcv1, ohlcv2) && // upside gap
                ohlcv3.Open < ohlcv2.Close && ohlcv3.Open > ohlcv2.Open && // 3rd: opens within the previous white real body
                ohlcv3.Close < ohlcv2.Open && // 3rd: closes under the previous white real body
                ohlcv3.Close > Math.Max(ohlcv1.Close, ohlcv1.Open) && // 3rd: closes inside the gap
                Math.Abs(RealBody(ohlcv2) - RealBody(ohlcv3)) < nearCriterion.AverageValue(ohlcvList, 2, ohlcv2)) // the size of two real bodies are near the same
                return 100;

            if (IsBlack(ohlcv2) && // 2nd: black (first candle after the gap)
                IsWhite(ohlcv3) && // 3rd: white (second candle after the gap)
                IsRealBodyGapDown(ohlcv1, ohlcv2) && // downside gap
                ohlcv3.Open < ohlcv2.Open && ohlcv3.Open > ohlcv2.Close && // 3rd: opens within the previous black real body
                ohlcv3.Close > ohlcv2.Open && // 3rd: closes above the previous black real body
                ohlcv3.Close < Math.Min(ohlcv1.Close, ohlcv1.Open) && // 3rd: closes inside the gap
                Math.Abs(RealBody(ohlcv2) - RealBody(ohlcv3)) < nearCriterion.AverageValue(ohlcvList, 2, ohlcv2)) // the size of two real bodies are near the same
                return -100;

            return 0;
        }
    }
}
