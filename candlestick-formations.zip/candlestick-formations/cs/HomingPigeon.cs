﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the HomingPigeon pattern.
        /// </summary>
        public const int HomingPigeonCandlesticks = 2;

        /// <summary>
        /// The HomingPigeon pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int HomingPigeon(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - HomingPigeonCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count];

            // Must have:
            // - first candle: long black candle,
            // - second candle: short black real body completely inside the previous day's body,
            // The meaning of "moves well within" is specified with HomingPigeonPenetrationFactor
            // and "moves" should mean the real body should not be short - Greg Morris wants it to be long,
            // someone else want it to be relatively long.
            // Output is positive (1 to 100): a homing pigeon is always bullish.
            // The user should consider that a homing pigeon is significant when it appears in an downtrend,
            // while this function does not consider the trend.

            if (IsBlack(ohlcv1) && // 1st: black
                IsBlack(ohlcv2) && // 2nd: black
                ohlcv2.Open < ohlcv1.Open && ohlcv2.Close > ohlcv1.Close && // 2nd: engulfed by first
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv2)) // 2nd: short real body
                return 100;

            return 0;
        }
    }
}
