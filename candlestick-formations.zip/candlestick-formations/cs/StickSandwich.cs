﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the StickSandwich pattern.
        /// </summary>
        public const int StickSandwichCandlesticks = 3;

        /// <summary>
        /// The StickSandwich pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int StickSandwich(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - StickSandwichCandlesticks;
            if (count < equalCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: black candle,
            // - second candle: white candle that trades only above the prior close (low > prior close),
            // - third candle: black candle with the close equal to the first candle's close.
            // Output is always positive (1 to 100): stick sandwich is always bullish.
            // The user should consider that stick sandwich is significant when appearing in a downtrend,
            // while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv2) && // 2nd: white
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv2.Low > ohlcv1.Close) // 2nd: trades only above the prior close
            {
                double equal = equalCriterion.AverageValue(ohlcvList, 3, ohlcv1);
                if (ohlcv3.Close <= ohlcv1.Close + equal && ohlcv2.Open >= ohlcv3.Close - equal) // 3rd: close equal to the first candle's close
                    return 100;
            }

            return 0;
        }
    }
}
