﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the MorningDojiStar pattern.
        /// </summary>
        public const int MorningDojiStarCandlesticks = 3;

        /// <summary>
        /// Specifies the meaning of "moves well within" for a morning doji star pattern.
        /// The value must be in range [0, 3e+37], the default value is 0.3.
        /// </summary>
        public double MorningDojiStarPenetrationFactor = 0.3;

        /// <summary>
        /// The MorningDojiStar pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int MorningDojiStar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - MorningDojiStarCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod ||
                count < dojiRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long black real body,
            // - second candle: doji gapping down,
            // - third candle: white real body that moves well within the first candle's real body.
            // The meaning of "moves well within" is specified with MorningDojiStarPenetrationFactor
            // and "moves" should mean the real body should not be short - Greg Morris wants it to be long,
            // someone else want it to be relatively long.
            // Output is positive (1 to 100): morning doji star is always bullish.
            // The user should consider that morning doji star is significant when it appears in a downtrend, while this function does not consider it.

            if (IsBlack(ohlcv1) && // 1st: black
                IsWhite(ohlcv3) && // 3rd: white
                ohlcv3.Close > ohlcv1.Close + RealBody(ohlcv1) * MorningDojiStarPenetrationFactor && // 3rd: closes well within first candle's real body
                IsRealBodyGapDown(ohlcv1, ohlcv2) && // 2nd: gapping down
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= dojiRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: doji
                RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: longer than short
                return 100;

            return 0;
        }
    }
}
