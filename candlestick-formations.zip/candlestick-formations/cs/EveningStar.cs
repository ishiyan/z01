﻿using System.Collections.Generic;

namespace Mbst.Trading.CandlestickPatterns
{
    /// <summary>
    /// The crisp candlestick pattern recognition engine.
    /// </summary>
    public partial class CandlestickPatterns
    {
        /// <summary>
        /// The number of candlesticks in the EveningStar pattern.
        /// </summary>
        public const int EveningStarCandlesticks = 3;

        /// <summary>
        /// Specifies the meaning of "moves well within" for an evening star pattern.
        /// The value must be in range [0, 3e+37], the default value is 0.3.
        /// </summary>
        public double EveningStarPenetrationFactor = 0.3;

        /// <summary>
        /// The EveningStar pattern.
        /// </summary>
        /// <param name="ohlcvList">A list of candles.</param>
        /// <returns>A negative integer (-100) if there is a bearish match, a positive integer (+100) if there is a bullish match, 0 if no match.</returns>
        public int EveningStar(List<Ohlcv> ohlcvList)
        {
            // Check if we have sufficient number of samples.
            int count = ohlcvList.Count - EveningStarCandlesticks;
            if (count < longRealBodyCriterion.AveragePeriod ||
                count < shortRealBodyCriterion.AveragePeriod)
                return 0;

            Ohlcv ohlcv1 = ohlcvList[count], ohlcv2 = ohlcvList[++count], ohlcv3 = ohlcvList[++count];

            // Must have:
            // - first candle: long white real body,
            // - second candle: star (short real body gapping up),
            // - third candle: black real body that moves well within the first candle's real body.
            // The meaning of "moves well within" is specified with EveningStarPenetrationFactor
            // and "moves" should mean the real body should not be short - Greg Morris wants it to be long,
            // someone else want it to be relatively long.
            // Output is always negative (-1 to -100): evening star is always bearish.
            // The user should consider that an evening star is significant when it appears in an uptrend,
            // while this function does not consider the trend.

            if (IsWhite(ohlcv1) && // 1st: white
                IsBlack(ohlcv3) && // 3rd: black
                ohlcv3.Close < ohlcv1.Close - RealBody(ohlcv1) * EveningStarPenetrationFactor && // 3rd: closes well within first candle's real body
                IsRealBodyGapUp(ohlcv1, ohlcv2) && // 2nd: gapping up
                RealBody(ohlcv1) > longRealBodyCriterion.AverageValue(ohlcvList, 3, ohlcv1) && // 1st: long real body
                RealBody(ohlcv2) <= shortRealBodyCriterion.AverageValue(ohlcvList, 2, ohlcv2) && // 2nd: short
                RealBody(ohlcv3) > shortRealBodyCriterion.AverageValue(ohlcvList, 1, ohlcv3)) // 3rd: longer than short
                return -100;

            return 0;
        }
    }
}
